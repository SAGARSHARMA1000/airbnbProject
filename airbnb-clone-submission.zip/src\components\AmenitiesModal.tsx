'use client';

import React, { useState, useMemo } from 'react';
import { X, Search } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { AmenityItem } from '@/data/listingData';
import { DynamicIcon } from '@/components/DynamicIcon';

interface AmenitiesModalProps {
  isOpen: boolean;
  onClose: () => void;
  amenities: AmenityItem[];
}

export const AmenitiesModal: React.FC<AmenitiesModalProps> = ({
  isOpen,
  onClose,
  amenities,
}) => {
  const [searchQuery, setSearchQuery] = useState('');

  // Group amenities by category
  const groupedAmenities = useMemo(() => {
    const filtered = searchQuery.trim()
      ? amenities.filter((a) =>
          a.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          (a.description && a.description.toLowerCase().includes(searchQuery.toLowerCase()))
        )
      : amenities;

    const map = new Map<string, AmenityItem[]>();
    filtered.forEach((item) => {
      const cat = item.category || 'General';
      if (!map.has(cat)) map.set(cat, []);
      map.get(cat)!.push(item);
    });
    return map;
  }, [amenities, searchQuery]);

  if (!isOpen) return null;

  return (
    <AnimatePresence>
      <div
        role="dialog"
        aria-modal="true"
        aria-label="All amenities modal"
        className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4"
      >
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 20 }}
          className="bg-white rounded-3xl max-w-2xl w-full p-6 sm:p-8 shadow-2xl border border-gray-100 max-h-[85vh] flex flex-col"
        >
          {/* Header */}
          <div className="flex justify-between items-center pb-4 border-b border-gray-100">
            <h3 className="text-xl font-bold text-gray-900">What this place offers</h3>
            <button
              onClick={onClose}
              className="p-2 hover:bg-gray-100 rounded-full transition"
              aria-label="Close amenities modal"
            >
              <X className="w-5 h-5 text-gray-600" />
            </button>
          </div>

          {/* Search Bar */}
          <div className="relative my-4">
            <Search className="w-4 h-4 text-gray-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search amenities (e.g., pool, wifi, kitchen)"
              className="w-full pl-10 pr-4 py-2.5 rounded-full border border-gray-300 text-sm focus:outline-none focus:ring-2 focus:ring-black"
            />
          </div>

          {/* Amenities List */}
          <div className="flex-1 overflow-y-auto pr-2 space-y-8 divide-y divide-gray-100">
            {groupedAmenities.size === 0 ? (
              <p className="text-sm text-gray-500 py-8 text-center">
                No amenities found matching &quot;{searchQuery}&quot;
              </p>
            ) : (
              Array.from(groupedAmenities.entries()).map(([category, items], idx) => (
                <div key={category} className={idx === 0 ? '' : 'pt-6'}>
                  <h4 className="font-semibold text-gray-900 text-base mb-4">
                    {category}
                  </h4>
                  <div className="space-y-4">
                    {items.map((item, itemIdx) => (
                      <div key={itemIdx} className="flex items-start gap-3.5 pb-2">
                        <div className="text-gray-700 pt-0.5 shrink-0">
                          <DynamicIcon name={item.iconName} className="w-5 h-5 stroke-[1.75]" />
                        </div>
                        <div>
                          <p className="text-sm font-medium text-gray-900 leading-snug">
                            {item.name}
                          </p>
                          {item.description && (
                            <p className="text-xs text-gray-500 mt-0.5">
                              {item.description}
                            </p>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ))
            )}
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
