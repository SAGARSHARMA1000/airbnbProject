'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { Star } from 'lucide-react';
import { ListingDetails, ReviewItem } from '@/data/listingData';
import { ReviewsModal } from '@/components/ReviewsModal';

interface ReviewsSectionProps {
  listing: ListingDetails;
}

export const ReviewsSection: React.FC<ReviewsSectionProps> = ({ listing }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);

  const categories = [
    { label: 'Cleanliness', score: listing.rating.categories.cleanliness },
    { label: 'Accuracy', score: listing.rating.categories.accuracy },
    { label: 'Communication', score: listing.rating.categories.communication },
    { label: 'Location', score: listing.rating.categories.location },
    { label: 'Check-in', score: listing.rating.categories.checkIn },
    { label: 'Value', score: listing.rating.categories.value },
  ];

  return (
    <>
      <section id="reviews-section" className="py-12 border-b border-gray-200">
        {/* Rating Header */}
        <div className="flex items-center gap-2 mb-8">
          <Star className="w-6 h-6 fill-gray-900 text-gray-900" />
          <h3 className="text-2xl font-bold text-gray-900">
            {listing.rating.overall.toFixed(2)} · {listing.rating.reviewCount} reviews
          </h3>
        </div>

        {/* 6 Category Rating Breakdown Progress Bars */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-x-12 gap-y-4 mb-10">
          {categories.map((cat) => (
            <div key={cat.label} className="flex items-center justify-between gap-4">
              <span className="text-sm font-normal text-gray-800">{cat.label}</span>
              <div className="flex items-center gap-3 w-36">
                <div className="flex-1 bg-gray-200 h-1 rounded-full overflow-hidden">
                  <div
                    className="bg-gray-900 h-full rounded-full"
                    style={{ width: `${(cat.score / 5.0) * 100}%` }}
                  />
                </div>
                <span className="text-xs font-bold text-gray-900 w-6 text-right">
                  {cat.score.toFixed(1)}
                </span>
              </div>
            </div>
          ))}
        </div>

        {/* 2-Column Grid of Featured Reviews */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-x-16 gap-y-10">
          {listing.reviews.slice(0, 6).map((review: ReviewItem) => (
            <div key={review.id} className="space-y-3">
              {/* Reviewer Profile */}
              <div className="flex items-center gap-3">
                <div className="relative w-12 h-12 rounded-full overflow-hidden bg-gray-100 shrink-0 border border-gray-100">
                  <Image
                    src={review.author.avatar}
                    alt={review.author.name}
                    fill
                    sizes="48px"
                    className="object-cover"
                  />
                </div>
                <div>
                  <h4 className="font-semibold text-gray-900 text-sm">
                    {review.author.name}
                  </h4>
                  <p className="text-xs text-gray-500">
                    {review.author.location}
                  </p>
                </div>
              </div>

              {/* Star Rating & Stay Date */}
              <div className="flex items-center gap-2 text-xs text-gray-800">
                <div className="flex text-gray-900">
                  {[...Array(review.rating)].map((_, i) => (
                    <Star key={i} className="w-3 h-3 fill-gray-900 text-gray-900" />
                  ))}
                </div>
                <span>·</span>
                <span className="font-semibold text-gray-900">{review.date}</span>
                <span>·</span>
                <span className="text-gray-500">{review.stayDetails}</span>
              </div>

              {/* Review Text */}
              <p className="text-sm text-gray-700 leading-relaxed font-normal line-clamp-4">
                {review.comment}
              </p>

              {/* Host Response Snippet */}
              {review.hostResponse && (
                <div className="mt-2 pl-3 border-l-2 border-gray-200 text-xs text-gray-600">
                  <span className="font-semibold text-gray-800 block mb-0.5">
                    Response from {listing.host.name}:
                  </span>
                  <p className="line-clamp-2">{review.hostResponse.comment}</p>
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Show All Reviews Button */}
        <div className="mt-10">
          <button
            onClick={() => setIsModalOpen(true)}
            className="border border-gray-900 hover:bg-gray-50 text-gray-900 font-semibold px-6 py-3 rounded-xl transition cursor-pointer text-sm shadow-2xs"
          >
            Show all {listing.rating.reviewCount} reviews
          </button>
        </div>
      </section>

      {/* Full Reviews Modal */}
      <ReviewsModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        listing={listing}
      />
    </>
  );
};
