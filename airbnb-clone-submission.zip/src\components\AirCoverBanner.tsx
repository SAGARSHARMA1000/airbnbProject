'use client';

import React, { useState } from 'react';
import { ShieldCheck, X, Check } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export const AirCoverBanner: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <>
      <div className="py-6 border-b border-gray-200">
        <div className="flex items-center gap-1 mb-2">
          <span className="text-[#FF385C] font-extrabold text-xl tracking-tight">air</span>
          <span className="text-gray-900 font-extrabold text-xl tracking-tight">cover</span>
        </div>
        <p className="text-sm text-gray-600 leading-relaxed font-normal">
          Every booking includes free protection from Host cancellations, listing inaccuracies, and other issues like trouble checking in.
        </p>
        <button
          onClick={() => setIsOpen(true)}
          className="mt-3 text-sm font-semibold underline text-gray-900 hover:text-black cursor-pointer"
        >
          Learn more
        </button>
      </div>

      {/* AirCover Details Modal */}
      <AnimatePresence>
        {isOpen && (
          <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-3xl max-w-xl w-full p-6 sm:p-8 shadow-2xl border border-gray-100 max-h-[90vh] overflow-y-auto"
            >
              <div className="flex justify-between items-center mb-6">
                <div className="flex items-center gap-1">
                  <span className="text-[#FF385C] font-black text-2xl tracking-tight">air</span>
                  <span className="text-gray-900 font-black text-2xl tracking-tight">cover</span>
                </div>
                <button
                  onClick={() => setIsOpen(false)}
                  className="p-2 hover:bg-gray-100 rounded-full transition"
                  aria-label="Close modal"
                >
                  <X className="w-5 h-5 text-gray-600" />
                </button>
              </div>

              <h3 className="text-xl font-bold text-gray-900 mb-2">
                AirCover is comprehensive protection included for free with every booking.
              </h3>
              <p className="text-sm text-gray-600 mb-6 leading-relaxed">
                Airbnb provides top-to-bottom coverage to guarantee your peace of mind from reservation to checkout.
              </p>

              <div className="space-y-4 text-sm">
                <div className="p-4 rounded-xl bg-gray-50 border border-gray-100">
                  <div className="flex items-center gap-2 font-semibold text-gray-900 mb-1">
                    <Check className="w-4 h-4 text-emerald-600" />
                    <span>Booking Protection Guarantee</span>
                  </div>
                  <p className="text-gray-600 text-xs pl-6">
                    In the unlikely event a Host needs to cancel within 30 days of check-in, we’ll find you a similar or better home or refund you.
                  </p>
                </div>

                <div className="p-4 rounded-xl bg-gray-50 border border-gray-100">
                  <div className="flex items-center gap-2 font-semibold text-gray-900 mb-1">
                    <Check className="w-4 h-4 text-emerald-600" />
                    <span>Check-In Guarantee</span>
                  </div>
                  <p className="text-gray-600 text-xs pl-6">
                    If you cannot check into your home and the Host cannot resolve the issue, we’ll help find you a similar home or issue a full refund.
                  </p>
                </div>

                <div className="p-4 rounded-xl bg-gray-50 border border-gray-100">
                  <div className="flex items-center gap-2 font-semibold text-gray-900 mb-1">
                    <Check className="w-4 h-4 text-emerald-600" />
                    <span>Get-What-You-Booked Guarantee</span>
                  </div>
                  <p className="text-gray-600 text-xs pl-6">
                    If at any time during your stay you find your listing isn’t as advertised, you have 3 days to report it and we’ll make it right.
                  </p>
                </div>

                <div className="p-4 rounded-xl bg-gray-50 border border-gray-100">
                  <div className="flex items-center gap-2 font-semibold text-gray-900 mb-1">
                    <ShieldCheck className="w-4 h-4 text-emerald-600" />
                    <span>24-Hour Safety Line</span>
                  </div>
                  <p className="text-gray-600 text-xs pl-6">
                    If you ever feel unsafe, you’ll get priority access to specially-trained safety agents, day or night.
                  </p>
                </div>
              </div>

              <div className="mt-8 pt-4 border-t border-gray-100 flex justify-end">
                <button
                  onClick={() => setIsOpen(false)}
                  className="bg-gray-900 text-white font-semibold px-6 py-2.5 rounded-xl hover:bg-black transition"
                >
                  Understood
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </>
  );
};
