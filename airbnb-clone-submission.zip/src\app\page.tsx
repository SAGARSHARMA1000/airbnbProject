'use client';

import React, { useState } from 'react';
import { Navbar } from '@/components/Navbar';
import { ListingHeader } from '@/components/ListingHeader';
import { PhotoGallery } from '@/components/PhotoGallery';
import { LightboxModal } from '@/components/LightboxModal';
import { HostQuickInfo } from '@/components/HostQuickInfo';
import { GuestFavoriteBanner } from '@/components/GuestFavoriteBanner';
import { HighlightsSection } from '@/components/HighlightsSection';
import { AirCoverBanner } from '@/components/AirCoverBanner';
import { DescriptionSection } from '@/components/DescriptionSection';
import { SleepingArrangements } from '@/components/SleepingArrangements';
import { AmenitiesSection } from '@/components/AmenitiesSection';
import { DatePickerSection } from '@/components/DatePickerSection';
import { StickyReservationCard } from '@/components/StickyReservationCard';
import { ReviewsSection } from '@/components/ReviewsSection';
import { LocationMap } from '@/components/LocationMap';
import { HostProfileSection } from '@/components/HostProfileSection';
import { ThingsToKnowSection } from '@/components/ThingsToKnowSection';
import { MobileBottomBar } from '@/components/MobileBottomBar';
import { Footer } from '@/components/Footer';
import { ShareModal } from '@/components/ShareModal';
import { LISTING_DATA } from '@/data/listingData';
import { motion, AnimatePresence } from 'framer-motion';
import { Heart, CheckCircle2 } from 'lucide-react';

export default function ListingPage() {
  const [isLightboxOpen, setIsLightboxOpen] = useState(false);
  const [lightboxInitialIndex, setLightboxInitialIndex] = useState(0);
  const [isShareModalOpen, setIsShareModalOpen] = useState(false);
  const [isSaved, setIsSaved] = useState(false);
  const [showSaveToast, setShowSaveToast] = useState(false);

  // Shared Date Range State: Defaults to Oct 12, 2026 - Oct 17, 2026 (5 nights)
  const [checkIn, setCheckIn] = useState<Date | null>(new Date(2026, 9, 12));
  const [checkOut, setCheckOut] = useState<Date | null>(new Date(2026, 9, 17));

  const handleOpenLightbox = (index: number = 0) => {
    setLightboxInitialIndex(index);
    setIsLightboxOpen(true);
  };

  const handleToggleSave = () => {
    const nextSavedState = !isSaved;
    setIsSaved(nextSavedState);
    setShowSaveToast(true);
    setTimeout(() => {
      setShowSaveToast(false);
    }, 3000);
  };

  const scrollToSection = (sectionId: string) => {
    const el = document.getElementById(sectionId);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-white text-gray-900 selection:bg-[#FF385C]/20 selection:text-[#FF385C]">
      {/* Top Navbar */}
      <Navbar savedCount={isSaved ? 1 : 0} />

      {/* Main Container */}
      <main className="flex-1 max-w-[1280px] mx-auto px-4 sm:px-8 xl:px-12 w-full pb-20 md:pb-12">
        {/* Listing Header: Title, Rating, Location, Share/Save */}
        <ListingHeader
          listing={LISTING_DATA}
          isSaved={isSaved}
          onToggleSave={handleToggleSave}
          onOpenShareModal={() => setIsShareModalOpen(true)}
          onScrollToReviews={() => scrollToSection('reviews-section')}
          onScrollToMap={() => scrollToSection('location-section')}
        />

        {/* 5-Photo Responsive Hero Mosaic */}
        <PhotoGallery
          photos={LISTING_DATA.photos}
          onOpenLightbox={handleOpenLightbox}
        />

        {/* 2-Column Main Content Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 mt-8">
          {/* Left Main Content Column (7 cols on lg, 8 on xl) */}
          <div className="lg:col-span-7 xl:col-span-8 space-y-0">
            {/* Host Quick Info */}
            <HostQuickInfo
              listing={LISTING_DATA}
              onHostClick={() => scrollToSection('host-section')}
            />

            {/* Guest Favorite Banner */}
            {LISTING_DATA.rating.isGuestFavorite && (
              <GuestFavoriteBanner
                overallRating={LISTING_DATA.rating.overall}
                reviewCount={LISTING_DATA.rating.reviewCount}
              />
            )}

            {/* Property Highlights */}
            <HighlightsSection highlights={LISTING_DATA.highlights} />

            {/* AirCover Banner */}
            <AirCoverBanner />

            {/* Property Description */}
            <DescriptionSection
              summary={LISTING_DATA.description.summary}
              theSpace={LISTING_DATA.description.theSpace}
              guestAccess={LISTING_DATA.description.guestAccess}
              otherDetails={LISTING_DATA.description.otherDetails}
            />

            {/* Sleeping Arrangements */}
            <SleepingArrangements bedrooms={LISTING_DATA.bedrooms} />

            {/* Amenities Grid & Modal */}
            <AmenitiesSection amenities={LISTING_DATA.amenities} />

            {/* Interactive Calendar / Date Picker */}
            <div id="calendar-section">
              <DatePickerSection
                checkIn={checkIn}
                checkOut={checkOut}
                onSelectDates={(inDate, outDate) => {
                  setCheckIn(inDate);
                  setCheckOut(outDate);
                }}
              />
            </div>
          </div>

          {/* Right Column: Sticky Floating Reservation Widget */}
          <div className="hidden lg:block lg:col-span-5 xl:col-span-4">
            <StickyReservationCard
              listing={LISTING_DATA}
              checkIn={checkIn}
              checkOut={checkOut}
              onOpenCalendar={() => scrollToSection('calendar-section')}
              onScrollToReviews={() => scrollToSection('reviews-section')}
            />
          </div>
        </div>

        {/* Reviews Section */}
        <ReviewsSection listing={LISTING_DATA} />

        {/* Interactive Location Map */}
        <LocationMap listing={LISTING_DATA} />

        {/* Detailed Host Profile Section */}
        <HostProfileSection listing={LISTING_DATA} />

        {/* Things to Know Policies Section */}
        <ThingsToKnowSection listing={LISTING_DATA} />
      </main>

      {/* Mobile Fixed Bottom Booking Bar */}
      <MobileBottomBar
        pricePerNight={LISTING_DATA.pricing.basePricePerNight}
        checkIn={checkIn}
        checkOut={checkOut}
        onReserve={() => scrollToSection('calendar-section')}
      />

      {/* Global Lightbox Gallery Modal */}
      <LightboxModal
        isOpen={isLightboxOpen}
        onClose={() => setIsLightboxOpen(false)}
        photos={LISTING_DATA.photos}
        initialIndex={lightboxInitialIndex}
        isSaved={isSaved}
        onToggleSave={handleToggleSave}
        onOpenShare={() => setIsShareModalOpen(true)}
      />

      {/* Share Modal */}
      <ShareModal
        isOpen={isShareModalOpen}
        onClose={() => setIsShareModalOpen(false)}
        listing={LISTING_DATA}
      />

      {/* Save to Wishlist Animated Floating Toast */}
      <AnimatePresence>
        {showSaveToast && (
          <motion.div
            initial={{ opacity: 0, y: 50, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 20, scale: 0.9 }}
            className="fixed bottom-20 sm:bottom-8 right-6 z-50 bg-gray-900 text-white px-5 py-3.5 rounded-2xl shadow-2xl flex items-center gap-3 border border-white/10"
          >
            {isSaved ? (
              <>
                <Heart className="w-5 h-5 fill-[#FF385C] text-[#FF385C]" />
                <span className="text-sm font-semibold">Saved to your Wishlist</span>
              </>
            ) : (
              <>
                <CheckCircle2 className="w-5 h-5 text-gray-400" />
                <span className="text-sm font-semibold">Removed from Wishlist</span>
              </>
            )}
          </motion.div>
        )}
      </AnimatePresence>

      {/* Footer */}
      <Footer />
    </div>
  );
}
