'use client';

import React, { useState, useRef, useEffect } from 'react';
import { Search, Globe, Menu, User, Heart, HelpCircle, Sparkles, X } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

interface NavbarProps {
  onSearchClick?: () => void;
  savedCount?: number;
}

export const Navbar: React.FC<NavbarProps> = ({ savedCount = 0 }) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isSearchModalOpen, setIsSearchModalOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<'stays' | 'experiences'>('stays');
  const [destination, setDestination] = useState('Oia, Santorini');
  const menuRef = useRef<HTMLDivElement>(null);

  // Close menu on click outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setIsMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  return (
    <>
      <header className="sticky top-0 z-40 bg-white border-b border-gray-200 transition-shadow">
        <div className="max-w-[1280px] mx-auto px-4 sm:px-8 xl:px-12 h-20 flex items-center justify-between">
          {/* Logo */}
          <div className="flex items-center gap-1.5 cursor-pointer">
            <svg
              className="w-8 h-8 text-[#FF385C]"
              viewBox="0 0 32 32"
              fill="currentColor"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path d="M16 1c2.008 0 3.463.963 4.751 3.269l.533.988c3.084 5.753 7.828 15.342 7.828 18.243 0 4.673-3.645 7.5-8.5 7.5-3.053 0-5.463-1.424-7.612-4.106C8.85 29.576 6.44 31 3.387 31 1.52 31 0 29.5 0 23.5c0-2.901 4.744-12.49 7.828-18.243l.533-.988C9.65 1.963 11.105 1 13.113 1H16zm0 2h-2.887c-1.394 0-2.457.65-3.527 2.574l-.533.988C6.012 12.247 1.999 21.054 1.999 23.5c0 4.298.924 5.5 2.388 5.5 2.585 0 4.887-1.748 6.786-5.148l.781-1.397.778 1.397C14.631 27.252 16.933 29 19.518 29c1.464 0 2.388-1.202 2.388-5.5 0-2.446-4.013-11.253-7.054-16.938l-.533-.988C13.25 3.65 12.187 3 10.793 3H16zm0 13c2.485 0 4.5 2.015 4.5 4.5S18.485 25 16 25s-4.5-2.015-4.5-4.5 2.015-4.5 4.5-4.5zm0 2c-1.381 0-2.5 1.119-2.5 2.5s1.119 2.5 2.5 2.5 2.5-1.119 2.5-2.5-1.119-2.5-2.5-2.5z" />
            </svg>
            <span className="text-[#FF385C] font-bold text-xl tracking-tight hidden md:inline">
              airbnb
            </span>
          </div>

          {/* Center Search Pill (Desktop) */}
          <div
            onClick={() => setIsSearchModalOpen(true)}
            className="hidden md:flex items-center border border-gray-300 rounded-full py-2 px-4 shadow-sm hover:shadow-md transition cursor-pointer text-sm font-medium"
          >
            <button className="px-3 border-r border-gray-200 text-gray-900 font-semibold truncate max-w-[140px]">
              {destination}
            </button>
            <button className="px-3 border-r border-gray-200 text-gray-900 font-semibold">
              Any week
            </button>
            <button className="px-3 text-gray-500 font-normal">
              Add guests
            </button>
            <div className="bg-[#FF385C] p-2 rounded-full text-white ml-2">
              <Search className="w-3.5 h-3.5 stroke-[2.5]" />
            </div>
          </div>

          {/* Center Search Bar (Mobile) */}
          <div
            onClick={() => setIsSearchModalOpen(true)}
            className="flex md:hidden items-center border border-gray-300 rounded-full py-2 px-3 shadow-sm hover:shadow-md transition cursor-pointer text-xs w-full max-w-[260px] mx-2"
          >
            <Search className="w-4 h-4 text-gray-700 mr-2 shrink-0" />
            <div className="truncate">
              <span className="font-semibold text-gray-900 block truncate">{destination}</span>
              <span className="text-gray-500 text-[10px]">Any week · Add guests</span>
            </div>
          </div>

          {/* Right Navigation Controls */}
          <div className="flex items-center gap-1 sm:gap-2">
            <button className="hidden lg:block text-sm font-medium text-gray-800 hover:bg-gray-100 py-2.5 px-4 rounded-full transition">
              Airbnb your home
            </button>
            
            <button
              aria-label="Language and currency"
              className="p-2.5 hover:bg-gray-100 rounded-full transition text-gray-700"
            >
              <Globe className="w-4 h-4" />
            </button>

            {/* User Dropdown Menu Trigger */}
            <div className="relative" ref={menuRef}>
              <button
                onClick={() => setIsMenuOpen(!isMenuOpen)}
                aria-label="User navigation menu"
                aria-expanded={isMenuOpen}
                className="flex items-center gap-3 border border-gray-300 rounded-full py-1.5 px-3 hover:shadow-md transition cursor-pointer bg-white"
              >
                <Menu className="w-4 h-4 text-gray-700" />
                <div className="bg-gray-700 text-white rounded-full p-1 relative">
                  <User className="w-3.5 h-3.5" />
                  {savedCount > 0 && (
                    <span className="absolute -top-1 -right-1 bg-[#FF385C] text-white text-[9px] w-4 h-4 rounded-full flex items-center justify-center font-bold">
                      {savedCount}
                    </span>
                  )}
                </div>
              </button>

              {/* Dropdown Menu Popup */}
              <AnimatePresence>
                {isMenuOpen && (
                  <motion.div
                    initial={{ opacity: 0, scale: 0.95, y: -5 }}
                    animate={{ opacity: 1, scale: 1, y: 0 }}
                    exit={{ opacity: 0, scale: 0.95, y: -5 }}
                    transition={{ duration: 0.15 }}
                    className="absolute right-0 mt-3 w-64 bg-white rounded-2xl shadow-2xl border border-gray-100 py-2 z-50 text-sm text-gray-800 font-normal"
                  >
                    <div className="py-1 border-b border-gray-100 font-semibold">
                      <button className="w-full text-left px-4 py-2.5 hover:bg-gray-50 transition flex items-center justify-between">
                        <span>Sign up</span>
                        <span className="text-[11px] bg-red-50 text-[#FF385C] px-2 py-0.5 rounded-full font-medium">New</span>
                      </button>
                      <button className="w-full text-left px-4 py-2.5 hover:bg-gray-50 transition">
                        Log in
                      </button>
                    </div>

                    <div className="py-1 border-b border-gray-100">
                      <button className="w-full text-left px-4 py-2.5 hover:bg-gray-50 transition flex items-center gap-2.5">
                        <Heart className="w-4 h-4 text-gray-500" />
                        <span>Wishlists {savedCount > 0 ? `(${savedCount})` : ''}</span>
                      </button>
                      <button className="w-full text-left px-4 py-2.5 hover:bg-gray-50 transition flex items-center gap-2.5">
                        <Sparkles className="w-4 h-4 text-[#FF385C]" />
                        <span>Airbnb your home</span>
                      </button>
                      <button className="w-full text-left px-4 py-2.5 hover:bg-gray-50 transition">
                        Host an experience
                      </button>
                    </div>

                    <div className="py-1">
                      <button className="w-full text-left px-4 py-2.5 hover:bg-gray-50 transition flex items-center gap-2.5">
                        <HelpCircle className="w-4 h-4 text-gray-500" />
                        <span>Help Center</span>
                      </button>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>
        </div>
      </header>

      {/* Expanded Search Modal */}
      <AnimatePresence>
        {isSearchModalOpen && (
          <div className="fixed inset-0 z-50 bg-black/40 backdrop-blur-xs flex items-start justify-center pt-20 px-4">
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="bg-white rounded-3xl shadow-2xl p-6 w-full max-w-2xl border border-gray-100"
            >
              <div className="flex justify-between items-center mb-6">
                <div className="flex gap-4">
                  <button
                    onClick={() => setActiveTab('stays')}
                    className={`text-sm font-semibold pb-1 border-b-2 transition ${
                      activeTab === 'stays'
                        ? 'border-gray-900 text-gray-900'
                        : 'border-transparent text-gray-500 hover:text-gray-800'
                    }`}
                  >
                    Stays
                  </button>
                  <button
                    onClick={() => setActiveTab('experiences')}
                    className={`text-sm font-semibold pb-1 border-b-2 transition ${
                      activeTab === 'experiences'
                        ? 'border-gray-900 text-gray-900'
                        : 'border-transparent text-gray-500 hover:text-gray-800'
                    }`}
                  >
                    Experiences
                  </button>
                </div>
                <button
                  onClick={() => setIsSearchModalOpen(false)}
                  className="p-2 hover:bg-gray-100 rounded-full transition"
                >
                  <X className="w-5 h-5 text-gray-600" />
                </button>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="text-xs font-bold uppercase tracking-wider text-gray-700 block mb-1">
                    Where
                  </label>
                  <input
                    type="text"
                    value={destination}
                    onChange={(e) => setDestination(e.target.value)}
                    placeholder="Search destinations (e.g., Santorini, Amalfi Coast, Aspen)"
                    className="w-full px-4 py-3 border border-gray-300 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-black"
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="text-xs font-bold uppercase tracking-wider text-gray-700 block mb-1">
                      Check-in
                    </label>
                    <input
                      type="text"
                      readOnly
                      value="Oct 12, 2026"
                      className="w-full px-4 py-3 border border-gray-300 rounded-xl text-sm bg-gray-50 cursor-pointer"
                    />
                  </div>
                  <div>
                    <label className="text-xs font-bold uppercase tracking-wider text-gray-700 block mb-1">
                      Checkout
                    </label>
                    <input
                      type="text"
                      readOnly
                      value="Oct 17, 2026"
                      className="w-full px-4 py-3 border border-gray-300 rounded-xl text-sm bg-gray-50 cursor-pointer"
                    />
                  </div>
                </div>

                <div className="flex items-center justify-between pt-4 border-t border-gray-100">
                  <span className="text-xs text-gray-500">Press search to explore matching luxury villas</span>
                  <button
                    onClick={() => setIsSearchModalOpen(false)}
                    className="bg-gradient-to-r from-[#FF385C] to-[#E00B41] text-white font-semibold px-6 py-3 rounded-xl flex items-center gap-2 hover:opacity-95 transition shadow-md"
                  >
                    <Search className="w-4 h-4" />
                    <span>Search</span>
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </>
  );
};
