'use client';

import React, { useState } from 'react';
import { Globe, DollarSign, X } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export const Footer: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'popular' | 'islands' | 'coastal' | 'luxury'>('islands');
  const [isCurrencyModalOpen, setIsCurrencyModalOpen] = useState(false);
  const [selectedCurrency, setSelectedCurrency] = useState('USD ($)');
  const [selectedLanguage, setSelectedLanguage] = useState('English (US)');

  const footerLinks = {
    support: [
      { label: 'Help Center', href: '#' },
      { label: 'AirCover', href: '#' },
      { label: 'Anti-discrimination', href: '#' },
      { label: 'Disability support', href: '#' },
      { label: 'Cancellation options', href: '#' },
      { label: 'Report neighborhood concern', href: '#' },
    ],
    hosting: [
      { label: 'Airbnb your home', href: '#' },
      { label: 'AirCover for Hosts', href: '#' },
      { label: 'Hosting resources', href: '#' },
      { label: 'Community forum', href: '#' },
      { label: 'Hosting responsibly', href: '#' },
      { label: 'Airbnb-friendly apartments', href: '#' },
    ],
    airbnb: [
      { label: 'Newsroom', href: '#' },
      { label: 'New features', href: '#' },
      { label: 'Careers', href: '#' },
      { label: 'Investors', href: '#' },
      { label: 'Gift cards', href: '#' },
      { label: 'Airbnb.org emergency stays', href: '#' },
    ],
  };

  const destinations = {
    islands: [
      { name: 'Santorini', state: 'Cyclades, Greece' },
      { name: 'Mykonos', state: 'Aegean Islands' },
      { name: 'Crete', state: 'Greece' },
      { name: 'Capri', state: 'Naples, Italy' },
      { name: 'Mallorca', state: 'Balearic Islands' },
      { name: 'Ibiza', state: 'Spain' },
      { name: 'Hvar', state: 'Croatia' },
      { name: 'Corfu', state: 'Ionian Islands' },
    ],
    popular: [
      { name: 'Paris', state: 'Île-de-France' },
      { name: 'Rome', state: 'Lazio, Italy' },
      { name: 'London', state: 'United Kingdom' },
      { name: 'New York', state: 'New York' },
      { name: 'Tokyo', state: 'Kanto, Japan' },
      { name: 'Barcelona', state: 'Catalonia, Spain' },
      { name: 'Amsterdam', state: 'North Holland' },
      { name: 'Dubai', state: 'United Arab Emirates' },
    ],
    coastal: [
      { name: 'Amalfi', state: 'Campania, Italy' },
      { name: 'Positano', state: 'Amalfi Coast' },
      { name: 'Nice', state: 'French Riviera' },
      { name: 'Dubrovnik', state: 'Dalmatia' },
      { name: 'Santorini', state: 'Oia Cliffs' },
      { name: 'Cinque Terre', state: 'Liguria' },
      { name: 'Maui', state: 'Hawaii' },
      { name: 'Cabo San Lucas', state: 'Baja California' },
    ],
    luxury: [
      { name: 'Aspen', state: 'Colorado' },
      { name: 'St. Moritz', state: 'Switzerland' },
      { name: 'Monaco', state: 'French Riviera' },
      { name: 'Lake Como', state: 'Lombardy, Italy' },
      { name: 'Bora Bora', state: 'French Polynesia' },
      { name: 'Courchevel', state: 'French Alps' },
      { name: 'Tuscany', state: 'Italy' },
      { name: 'St. Barts', state: 'Caribbean' },
    ],
  };

  return (
    <footer className="bg-gray-50 border-t border-gray-200 text-gray-700 text-xs">
      <div className="max-w-[1280px] mx-auto px-4 sm:px-8 xl:px-12 py-10">
        {/* Inspiration for Future Getaways Tabs */}
        <div className="pb-8 border-b border-gray-200">
          <h4 className="text-base font-semibold text-gray-900 mb-4">
            Inspiration for future getaways
          </h4>

          {/* Tab Buttons */}
          <div className="flex gap-6 border-b border-gray-200 pb-2 text-sm font-medium overflow-x-auto scrollbar-none">
            {(['islands', 'popular', 'coastal', 'luxury'] as const).map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`pb-2 capitalize transition border-b-2 cursor-pointer ${
                  activeTab === tab
                    ? 'border-gray-900 text-gray-900 font-bold'
                    : 'border-transparent text-gray-500 hover:text-gray-900'
                }`}
              >
                {tab}
              </button>
            ))}
          </div>

          {/* Destinations Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-6">
            {destinations[activeTab].map((item, idx) => (
              <div key={idx} className="cursor-pointer hover:opacity-80">
                <span className="block font-semibold text-gray-900 text-xs">
                  {item.name}
                </span>
                <span className="text-[11px] text-gray-500">{item.state}</span>
              </div>
            ))}
          </div>
        </div>

        {/* 3 Main Link Columns */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 py-10 border-b border-gray-200">
          <div>
            <h5 className="font-bold text-gray-900 text-xs uppercase tracking-wider mb-4">
              Support
            </h5>
            <ul className="space-y-3">
              {footerLinks.support.map((link, idx) => (
                <li key={idx}>
                  <a href={link.href} className="hover:underline text-gray-600">
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h5 className="font-bold text-gray-900 text-xs uppercase tracking-wider mb-4">
              Hosting
            </h5>
            <ul className="space-y-3">
              {footerLinks.hosting.map((link, idx) => (
                <li key={idx}>
                  <a href={link.href} className="hover:underline text-gray-600">
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h5 className="font-bold text-gray-900 text-xs uppercase tracking-wider mb-4">
              Airbnb
            </h5>
            <ul className="space-y-3">
              {footerLinks.airbnb.map((link, idx) => (
                <li key={idx}>
                  <a href={link.href} className="hover:underline text-gray-600">
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-6 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-xs text-gray-600">
            <span>© 2026 Airbnb, Inc.</span>
            <span>·</span>
            <a href="#" className="hover:underline">Privacy</a>
            <span>·</span>
            <a href="#" className="hover:underline">Terms</a>
            <span>·</span>
            <a href="#" className="hover:underline">Sitemap</a>
            <span>·</span>
            <a href="#" className="hover:underline">Company details</a>
          </div>

          {/* Language / Currency / Socials */}
          <div className="flex items-center gap-6 font-semibold text-gray-900">
            <button
              onClick={() => setIsCurrencyModalOpen(true)}
              className="flex items-center gap-2 hover:underline cursor-pointer"
            >
              <Globe className="w-4 h-4" />
              <span>{selectedLanguage}</span>
            </button>

            <button
              onClick={() => setIsCurrencyModalOpen(true)}
              className="flex items-center gap-1 hover:underline cursor-pointer"
            >
              <DollarSign className="w-4 h-4" />
              <span>{selectedCurrency}</span>
            </button>

            {/* Social SVGs */}
            <div className="flex items-center gap-4 text-gray-800">
              <a href="#" aria-label="Facebook" className="hover:text-black transition">
                <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                  <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/>
                </svg>
              </a>
              <a href="#" aria-label="Twitter / X" className="hover:text-black transition">
                <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                  <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z"/>
                </svg>
              </a>
              <a href="#" aria-label="Instagram" className="hover:text-black transition">
                <svg className="w-4 h-4 fill-current" viewBox="0 0 24 24">
                  <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/>
                </svg>
              </a>
            </div>
          </div>
        </div>
      </div>

      {/* Language / Currency Modal */}
      <AnimatePresence>
        {isCurrencyModalOpen && (
          <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl border border-gray-100"
            >
              <div className="flex justify-between items-center pb-4 border-b border-gray-100 mb-6">
                <h3 className="text-xl font-bold text-gray-900">Language &amp; Currency</h3>
                <button
                  onClick={() => setIsCurrencyModalOpen(false)}
                  className="p-2 hover:bg-gray-100 rounded-full transition"
                >
                  <X className="w-5 h-5 text-gray-600" />
                </button>
              </div>

              <div className="space-y-6">
                <div>
                  <h4 className="font-semibold text-gray-900 text-sm mb-3">Choose a language</h4>
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    {['English (US)', 'English (UK)', 'Français (France)', 'Deutsch', 'Español', 'Italiano', 'Ελληνικά (Greek)', '日本語'].map((lang) => (
                      <button
                        key={lang}
                        onClick={() => setSelectedLanguage(lang)}
                        className={`p-2.5 rounded-xl border text-left font-medium transition cursor-pointer ${
                          selectedLanguage === lang
                            ? 'border-gray-900 bg-gray-50 text-gray-900 font-bold'
                            : 'border-gray-200 hover:bg-gray-50 text-gray-700'
                        }`}
                      >
                        {lang}
                      </button>
                    ))}
                  </div>
                </div>

                <div>
                  <h4 className="font-semibold text-gray-900 text-sm mb-3">Choose a currency</h4>
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    {['USD ($)', 'EUR (€)', 'GBP (£)', 'CAD ($)', 'AUD ($)', 'JPY (¥)', 'CHF (CHF)', 'INR (₹)'].map((curr) => (
                      <button
                        key={curr}
                        onClick={() => setSelectedCurrency(curr)}
                        className={`p-2.5 rounded-xl border text-left font-medium transition cursor-pointer ${
                          selectedCurrency === curr
                            ? 'border-gray-900 bg-gray-50 text-gray-900 font-bold'
                            : 'border-gray-200 hover:bg-gray-50 text-gray-700'
                        }`}
                      >
                        {curr}
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              <div className="mt-8 pt-4 border-t border-gray-100 flex justify-end">
                <button
                  onClick={() => setIsCurrencyModalOpen(false)}
                  className="bg-gray-900 text-white font-semibold px-6 py-2.5 rounded-xl hover:bg-black transition text-xs"
                >
                  Done
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </footer>
  );
};
