'use client';

import React, { useState } from 'react';
import { ChevronRight, X, Clock, Users, ShieldAlert, Ban, Sparkles } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { ListingDetails } from '@/data/listingData';

interface ThingsToKnowSectionProps {
  listing: ListingDetails;
}

export const ThingsToKnowSection: React.FC<ThingsToKnowSectionProps> = ({ listing }) => {
  const [activeModal, setActiveModal] = useState<'rules' | 'safety' | 'cancellation' | null>(null);

  return (
    <>
      <section className="py-12 border-b border-gray-200">
        <h3 className="text-2xl font-bold text-gray-900 mb-8">Things to know</h3>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-sm text-gray-800">
          {/* Column 1: House Rules */}
          <div className="space-y-3">
            <h4 className="font-semibold text-gray-900 text-base">House rules</h4>
            <div className="space-y-2 text-gray-600 font-normal">
              <p className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-gray-400 shrink-0" />
                <span>Check-in: {listing.houseRules.checkIn}</span>
              </p>
              <p className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-gray-400 shrink-0" />
                <span>Checkout before {listing.houseRules.checkOut}</span>
              </p>
              <p className="flex items-center gap-2">
                <Users className="w-4 h-4 text-gray-400 shrink-0" />
                <span>8 guests maximum</span>
              </p>
              <p className="flex items-center gap-2">
                <Ban className="w-4 h-4 text-gray-400 shrink-0" />
                <span>No smoking inside</span>
              </p>
            </div>
            <button
              onClick={() => setActiveModal('rules')}
              className="inline-flex items-center gap-1 font-semibold text-gray-900 underline hover:text-black pt-2 cursor-pointer"
            >
              <span>Show more</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          {/* Column 2: Safety & Property */}
          <div className="space-y-3">
            <h4 className="font-semibold text-gray-900 text-base">Safety & property</h4>
            <div className="space-y-2 text-gray-600 font-normal">
              <p className="flex items-center gap-2">
                <ShieldAlert className="w-4 h-4 text-gray-400 shrink-0" />
                <span>Carbon monoxide alarm installed</span>
              </p>
              <p className="flex items-center gap-2">
                <ShieldAlert className="w-4 h-4 text-gray-400 shrink-0" />
                <span>Smoke alarm installed</span>
              </p>
              <p className="flex items-center gap-2">
                <ShieldAlert className="w-4 h-4 text-amber-600 shrink-0" />
                <span>Pool has no child safety fence</span>
              </p>
              <p className="flex items-center gap-2">
                <ShieldAlert className="w-4 h-4 text-gray-400 shrink-0" />
                <span>Exterior entry security cameras</span>
              </p>
            </div>
            <button
              onClick={() => setActiveModal('safety')}
              className="inline-flex items-center gap-1 font-semibold text-gray-900 underline hover:text-black pt-2 cursor-pointer"
            >
              <span>Show more</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>

          {/* Column 3: Cancellation Policy */}
          <div className="space-y-3">
            <h4 className="font-semibold text-gray-900 text-base">Cancellation policy</h4>
            <div className="space-y-2 text-gray-600 font-normal">
              <p className="font-medium text-gray-900">{listing.cancellationPolicy.summary}</p>
              <p className="text-xs text-gray-500">{listing.cancellationPolicy.details}</p>
            </div>
            <button
              onClick={() => setActiveModal('cancellation')}
              className="inline-flex items-center gap-1 font-semibold text-gray-900 underline hover:text-black pt-2 cursor-pointer"
            >
              <span>Show more</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      </section>

      {/* Policy Details Modals */}
      <AnimatePresence>
        {activeModal && (
          <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-3xl max-w-lg w-full p-6 sm:p-8 shadow-2xl border border-gray-100 max-h-[80vh] overflow-y-auto"
            >
              <div className="flex justify-between items-center pb-4 border-b border-gray-100 mb-6">
                <h3 className="text-xl font-bold text-gray-900 capitalize">
                  {activeModal === 'rules' && 'House rules'}
                  {activeModal === 'safety' && 'Safety & property'}
                  {activeModal === 'cancellation' && 'Cancellation policy'}
                </h3>
                <button
                  onClick={() => setActiveModal(null)}
                  className="p-2 hover:bg-gray-100 rounded-full transition"
                  aria-label="Close modal"
                >
                  <X className="w-5 h-5 text-gray-600" />
                </button>
              </div>

              {activeModal === 'rules' && (
                <div className="space-y-4 text-sm text-gray-700">
                  <p className="font-semibold text-gray-900">
                    You’ll be staying in someone’s home, so please treat it with care and respect.
                  </p>
                  <div className="space-y-2">
                    <h5 className="font-semibold text-gray-900">Checking in and out</h5>
                    <p>• Check-in: {listing.houseRules.checkIn}</p>
                    <p>• Checkout: {listing.houseRules.checkOut}</p>
                    <p>• {listing.houseRules.selfCheckIn}</p>
                  </div>
                  <div className="space-y-2 pt-2">
                    <h5 className="font-semibold text-gray-900">During your stay</h5>
                    {listing.houseRules.rulesList.map((rule, idx) => (
                      <p key={idx}>• {rule}</p>
                    ))}
                  </div>
                </div>
              )}

              {activeModal === 'safety' && (
                <div className="space-y-4 text-sm text-gray-700">
                  <p className="font-semibold text-gray-900">
                    Safety devices and property details verified by Airbnb:
                  </p>
                  <div className="space-y-3">
                    {listing.safetyInfo.map((info, idx) => (
                      <div key={idx} className="flex items-start gap-2.5">
                        <Sparkles className="w-4 h-4 text-[#FF385C] shrink-0 mt-0.5" />
                        <span>{info}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {activeModal === 'cancellation' && (
                <div className="space-y-4 text-sm text-gray-700">
                  <div className="p-4 rounded-2xl bg-emerald-50 text-emerald-900 border border-emerald-200">
                    <span className="font-bold block mb-1">Free cancellation for 48 hours</span>
                    <span className="text-xs">
                      Cancel up to 48 hours after booking for a full 100% refund, provided check-in is at least 14 days away.
                    </span>
                  </div>
                  <p>
                    Cancel at least 7 days before check-in and get a 50% refund of the nightly rate, plus the full cleaning fee.
                  </p>
                  <p className="text-xs text-gray-500">
                    Review your Host’s cancellation policy which applies even if you cancel for illness or disruptions caused by travel.
                  </p>
                </div>
              )}

              <div className="mt-8 pt-4 border-t border-gray-100 flex justify-end">
                <button
                  onClick={() => setActiveModal(null)}
                  className="bg-gray-900 text-white font-semibold px-6 py-2.5 rounded-xl hover:bg-black transition text-sm"
                >
                  Close
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </>
  );
};
