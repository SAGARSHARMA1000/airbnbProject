'use client';

import React from 'react';
import { Star } from 'lucide-react';

interface GuestFavoriteBannerProps {
  overallRating: number;
  reviewCount: number;
}

export const GuestFavoriteBanner: React.FC<GuestFavoriteBannerProps> = ({
  overallRating,
  reviewCount,
}) => {
  return (
    <div className="py-6 border-b border-gray-200">
      <div className="border border-gray-200 rounded-2xl p-5 sm:p-6 bg-gradient-to-r from-amber-50/40 via-white to-amber-50/20 flex flex-col sm:flex-row items-center justify-between gap-4 shadow-2xs">
        {/* Left Badge with Laurel Wreath Graphic */}
        <div className="flex items-center gap-4">
          <div className="flex items-center justify-center text-amber-800">
            {/* Left Wreath Wing */}
            <svg className="w-8 h-10 text-amber-700/80" viewBox="0 0 24 32" fill="currentColor">
              <path d="M12 2C8 6 4 12 4 18c0 5 3 10 8 12-2-4-2-9 0-14 2-5 5-9 8-14-3 0-5-1-8-2z" opacity="0.8" />
              <circle cx="8" cy="10" r="1.5" />
              <circle cx="6" cy="16" r="1.5" />
              <circle cx="8" cy="22" r="1.5" />
            </svg>
            <div className="text-center px-1">
              <span className="block text-xs font-black uppercase tracking-wider text-amber-950">
                Guest
              </span>
              <span className="block text-xs font-black uppercase tracking-wider text-amber-950">
                favorite
              </span>
            </div>
            {/* Right Wreath Wing */}
            <svg className="w-8 h-10 text-amber-700/80 transform scale-x-[-1]" viewBox="0 0 24 32" fill="currentColor">
              <path d="M12 2C8 6 4 12 4 18c0 5 3 10 8 12-2-4-2-9 0-14 2-5 5-9 8-14-3 0-5-1-8-2z" opacity="0.8" />
              <circle cx="8" cy="10" r="1.5" />
              <circle cx="6" cy="16" r="1.5" />
              <circle cx="8" cy="22" r="1.5" />
            </svg>
          </div>

          <p className="text-sm font-medium text-gray-800 leading-snug">
            One of the most loved homes on Airbnb, according to guests
          </p>
        </div>

        {/* Right Rating Summary */}
        <div className="flex items-center gap-6 sm:border-l sm:border-gray-200 sm:pl-6 text-center">
          <div>
            <div className="flex items-center justify-center gap-1 text-lg font-bold text-gray-900">
              <span>{overallRating.toFixed(2)}</span>
              <Star className="w-4 h-4 fill-gray-900 text-gray-900" />
            </div>
            <div className="flex items-center justify-center gap-0.5 text-amber-500 mt-0.5">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="w-3 h-3 fill-amber-500 text-amber-500" />
              ))}
            </div>
          </div>

          <div className="border-l border-gray-200 pl-6">
            <div className="text-lg font-bold text-gray-900">{reviewCount}</div>
            <span className="text-xs text-gray-500 underline font-medium">Reviews</span>
          </div>
        </div>
      </div>
    </div>
  );
};
