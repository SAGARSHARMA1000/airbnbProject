import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";

const inter = Inter({
  subsets: ["latin"],
  variable: "--font-inter",
});

export const metadata: Metadata = {
  title: "Villa Asteria - Luxury Cliffside Infinity Pool & Caldera Sunset Views - Airbnb",
  description: "Entire luxury villa in Oia, Santorini, Greece. 8 guests · 4 bedrooms · 5 beds · 4.5 baths. Private heated infinity pool overlooking the Aegean Sea caldera.",
  icons: {
    icon: "/favicon.ico",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className={`${inter.variable} h-full antialiased`}>
      <body className="min-h-full flex flex-col font-sans bg-white text-gray-900">
        {children}
      </body>
    </html>
  );
}
