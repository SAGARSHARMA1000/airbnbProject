'use client';

import React, { useState } from 'react';
import { ChevronRight, X } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

interface DescriptionSectionProps {
  summary: string;
  theSpace: string;
  guestAccess: string;
  otherDetails: string;
}

export const DescriptionSection: React.FC<DescriptionSectionProps> = ({
  summary,
  theSpace,
  guestAccess,
  otherDetails,
}) => {
  const [isModalOpen, setIsModalOpen] = useState(false);

  return (
    <>
      <div className="py-6 border-b border-gray-200">
        <div className="text-base text-gray-800 leading-relaxed font-normal space-y-4">
          <p>{summary}</p>
          <div className="text-gray-700 text-sm whitespace-pre-line line-clamp-3">
            {theSpace}
          </div>
        </div>

        <button
          onClick={() => setIsModalOpen(true)}
          className="mt-4 inline-flex items-center gap-1 font-semibold text-gray-900 underline hover:text-black cursor-pointer text-sm"
        >
          <span>Show more</span>
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>

      {/* Description Full Modal */}
      <AnimatePresence>
        {isModalOpen && (
          <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 20 }}
              className="bg-white rounded-3xl max-w-2xl w-full p-6 sm:p-8 shadow-2xl border border-gray-100 max-h-[85vh] overflow-y-auto"
            >
              <div className="flex justify-between items-center mb-6 sticky top-0 bg-white pb-2 border-b border-gray-100">
                <h3 className="text-xl font-bold text-gray-900">About this space</h3>
                <button
                  onClick={() => setIsModalOpen(false)}
                  className="p-2 hover:bg-gray-100 rounded-full transition"
                  aria-label="Close modal"
                >
                  <X className="w-5 h-5 text-gray-600" />
                </button>
              </div>

              <div className="space-y-6 text-sm text-gray-800 leading-relaxed font-normal">
                <div>
                  <h4 className="font-semibold text-gray-900 text-base mb-2">Overview</h4>
                  <p>{summary}</p>
                </div>

                <div>
                  <h4 className="font-semibold text-gray-900 text-base mb-2">The space</h4>
                  <div className="whitespace-pre-line text-gray-700">{theSpace}</div>
                </div>

                <div>
                  <h4 className="font-semibold text-gray-900 text-base mb-2">Guest access</h4>
                  <p>{guestAccess}</p>
                </div>

                <div>
                  <h4 className="font-semibold text-gray-900 text-base mb-2">Other things to note</h4>
                  <p>{otherDetails}</p>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </>
  );
};
