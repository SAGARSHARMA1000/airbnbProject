'use client';

import React from 'react';
import { Star, Award, Share, Heart, MapPin } from 'lucide-react';
import { motion } from 'framer-motion';
import { ListingDetails } from '@/data/listingData';

interface ListingHeaderProps {
  listing: ListingDetails;
  isSaved: boolean;
  onToggleSave: () => void;
  onOpenShareModal: () => void;
  onScrollToReviews: () => void;
  onScrollToMap: () => void;
}

export const ListingHeader: React.FC<ListingHeaderProps> = ({
  listing,
  isSaved,
  onToggleSave,
  onOpenShareModal,
  onScrollToReviews,
  onScrollToMap,
}) => {
  return (
    <section className="pt-6 pb-4">
      {/* Title */}
      <h1 className="text-2xl sm:text-[26px] md:text-[28px] font-semibold text-gray-900 tracking-tight leading-tight">
        {listing.title}
      </h1>

      {/* Meta Subheading Bar */}
      <div className="flex flex-wrap items-center justify-between gap-y-2 gap-x-4 mt-2 text-sm text-gray-700">
        <div className="flex flex-wrap items-center gap-x-3 gap-y-1 font-medium">
          {/* Guest Favorite Badge */}
          {listing.rating.isGuestFavorite && (
            <div className="inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-md bg-amber-50 text-amber-900 text-xs font-semibold border border-amber-200/60 shadow-2xs">
              <Award className="w-3.5 h-3.5 text-amber-700" />
              <span>Guest favorite</span>
            </div>
          )}

          {/* Star Rating & Reviews */}
          <button
            onClick={onScrollToReviews}
            className="flex items-center gap-1 hover:underline text-gray-900 font-semibold cursor-pointer"
          >
            <Star className="w-4 h-4 fill-gray-900 text-gray-900" />
            <span>{listing.rating.overall.toFixed(2)}</span>
            <span className="text-gray-500 font-normal">·</span>
            <span className="underline">{listing.rating.reviewCount} reviews</span>
          </button>

          <span className="text-gray-400 font-light">·</span>

          {/* Superhost status */}
          {listing.host.isSuperhost && (
            <div className="flex items-center gap-1 text-gray-800">
              <Award className="w-4 h-4 text-[#FF385C]" />
              <span>Superhost</span>
            </div>
          )}

          <span className="text-gray-400 font-light">·</span>

          {/* Location Anchor */}
          <button
            onClick={onScrollToMap}
            className="flex items-center gap-1 underline font-semibold text-gray-800 hover:text-black cursor-pointer"
          >
            <MapPin className="w-3.5 h-3.5 text-gray-500" />
            <span>{listing.location.displayAddress}</span>
          </button>
        </div>

        {/* Share & Save Actions */}
        <div className="flex items-center gap-2">
          <button
            onClick={onOpenShareModal}
            className="flex items-center gap-2 px-3 py-2 rounded-lg hover:bg-gray-100 transition text-gray-800 font-medium text-sm underline cursor-pointer"
          >
            <Share className="w-4 h-4" />
            <span>Share</span>
          </button>

          <motion.button
            whileTap={{ scale: 0.9 }}
            onClick={onToggleSave}
            className="flex items-center gap-2 px-3 py-2 rounded-lg hover:bg-gray-100 transition text-gray-800 font-medium text-sm underline cursor-pointer"
          >
            <Heart
              className={`w-4 h-4 transition-colors ${
                isSaved
                  ? 'fill-[#FF385C] text-[#FF385C]'
                  : 'text-gray-800 hover:text-[#FF385C]'
              }`}
            />
            <span>{isSaved ? 'Saved' : 'Save'}</span>
          </motion.button>
        </div>
      </div>
    </section>
  );
};
