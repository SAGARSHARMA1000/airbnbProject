export interface PhotoItem {
  id: string;
  url: string;
  alt: string;
  category: 'All' | 'Living Room' | 'Bedrooms' | 'Infinity Pool & Caldera' | 'Kitchen & Dining' | 'Terrace';
  caption: string;
}

export interface AmenityItem {
  name: string;
  description?: string;
  iconName: string;
  category: string;
  isFeatured?: boolean;
}

export interface ReviewItem {
  id: string;
  author: {
    name: string;
    avatar: string;
    location: string;
    yearsOnAirbnb: string;
  };
  rating: number;
  date: string;
  stayDetails: string;
  comment: string;
  hostResponse?: {
    date: string;
    comment: string;
  };
}

export interface BedroomItem {
  id: string;
  title: string;
  bedType: string;
  features: string;
  iconName: string;
}

export interface ListingDetails {
  id: string;
  title: string;
  tagline: string;
  location: {
    neighborhood: string;
    city: string;
    region: string;
    country: string;
    displayAddress: string;
    lat: number;
    lng: number;
    description: string;
    gettingAround: string;
  };
  stats: {
    guests: number;
    bedrooms: number;
    beds: number;
    baths: number;
    propertyType: string;
  };
  rating: {
    overall: number;
    reviewCount: number;
    isGuestFavorite: boolean;
    categories: {
      cleanliness: number;
      accuracy: number;
      communication: number;
      location: number;
      checkIn: number;
      value: number;
    };
  };
  pricing: {
    basePricePerNight: number;
    currency: string;
    currencySymbol: string;
    cleaningFee: number;
    serviceFeeRate: number;
    taxRate: number;
    weeklyDiscountPercentage: number;
  };
  host: {
    name: string;
    avatar: string;
    isSuperhost: boolean;
    hostingSince: string;
    responseRate: string;
    responseTime: string;
    languages: string[];
    bio: string;
    coHosts: Array<{ name: string; avatar: string; role: string }>;
    stats: {
      reviews: number;
      rating: number;
      yearsHosting: number;
    };
  };
  highlights: Array<{
    title: string;
    description: string;
    iconName: string;
  }>;
  description: {
    summary: string;
    theSpace: string;
    guestAccess: string;
    otherDetails: string;
  };
  bedrooms: BedroomItem[];
  photos: PhotoItem[];
  amenities: AmenityItem[];
  reviews: ReviewItem[];
  houseRules: {
    checkIn: string;
    checkOut: string;
    selfCheckIn: string;
    rulesList: string[];
  };
  safetyInfo: string[];
  cancellationPolicy: {
    summary: string;
    details: string;
  };
}

export const LISTING_DATA: ListingDetails = {
  id: 'villa-asteria-santorini',
  title: 'Villa Asteria - Luxury Cliffside Infinity Pool & Caldera Sunset Views',
  tagline: 'Iconic cave villa with panoramic Aegean Sea sunsets and private heated infinity pool',
  location: {
    neighborhood: 'Oia Cliffs',
    city: 'Oia',
    region: 'Santorini, South Aegean',
    country: 'Greece',
    displayAddress: 'Oia, Santorini, Greece',
    lat: 36.4618,
    lng: 25.3753,
    description: 'Perched along the most prestigious cliffside tier in Oia, Villa Asteria commands completely unobstructed views of the volcanic caldera and world-famous Aegean sunset. Walk 4 minutes to historic Byzantine Castle ruins, blue-domed chapels, and Michelin-rated Mediterranean restaurants while enjoying absolute cliffside privacy.',
    gettingAround: 'Private transfer from Santorini Airport (JTR) or Athinios Port can be coordinated by your concierge. Free dedicated private parking is located 150m from the villa entrance.'
  },
  stats: {
    guests: 8,
    bedrooms: 4,
    beds: 5,
    baths: 4.5,
    propertyType: 'Entire villa'
  },
  rating: {
    overall: 4.98,
    reviewCount: 128,
    isGuestFavorite: true,
    categories: {
      cleanliness: 4.9,
      accuracy: 5.0,
      communication: 4.9,
      location: 5.0,
      checkIn: 5.0,
      value: 4.8
    }
  },
  pricing: {
    basePricePerNight: 650,
    currency: 'USD',
    currencySymbol: '$',
    cleaningFee: 150,
    serviceFeeRate: 0.14,
    taxRate: 0.12,
    weeklyDiscountPercentage: 10
  },
  host: {
    name: 'Elena & Nikos',
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=400&q=80',
    isSuperhost: true,
    hostingSince: 'March 2017',
    responseRate: '100%',
    responseTime: 'within an hour',
    languages: ['English', 'Greek', 'French', 'Italian'],
    bio: 'Architect and interior design duo native to the Cyclades. We lovingly restored Villa Asteria to celebrate traditional whitewashed Santorini cave heritage paired with contemporary organic luxury, bespoke linen bedding, and curated Greek artisan touches. We are committed to making your stay extraordinary.',
    coHosts: [
      {
        name: 'Giannis',
        avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=200&q=80',
        role: 'Dedicated Concierge'
      }
    ],
    stats: {
      reviews: 128,
      rating: 4.98,
      yearsHosting: 7
    }
  },
  highlights: [
    {
      title: 'Guest favorite',
      description: 'One of the most loved homes on Airbnb based on ratings, reviews, and reliability.',
      iconName: 'Award'
    },
    {
      title: 'Dedicated sea-view workspace',
      description: 'A private study room with 500 Mbps fiber optic Wi-Fi and ergonomic Herman Miller chair.',
      iconName: 'Laptop'
    },
    {
      title: 'Self check-in with smart lock',
      description: 'Check yourself in effortlessly with the exterior security keypad.',
      iconName: 'Key'
    },
    {
      title: 'Elena & Nikos is a Superhost',
      description: 'Superhosts are experienced, highly rated hosts committed to great stays.',
      iconName: 'ShieldCheck'
    },
    {
      title: 'Free cancellation for 48 hours',
      description: 'Get a full refund if you change your mind within 48 hours of booking.',
      iconName: 'CalendarCheck'
    }
  ],
  description: {
    summary: 'Immerse yourself in quintessential Greek island luxury at Villa Asteria. Carved directly into the volcanic cliff face of Oia, this masterfully designed 4-bedroom villa seamlessly combines whitewashed organic curves with ultra-luxurious modern appointments.',
    theSpace: `• The Infinity Pool & Caldera Terrace:
Featuring a private heated horizon infinity pool that blends seamlessly into the deep blue Aegean Sea. Sun lounger cabanas, a gas fire table, and an al fresco dining veranda provide front-row seating for the sunset.

• Living & Dining Suites:
Expansive vaulted ceilings, hand-plastered microcement floors, custom oak joinery, and minimalist designer furniture. The living room features a Sonos multi-zone sound system and floor-to-ceiling glass doors opening onto the terrace.

• Gourmet Chef's Kitchen:
Fully equipped with Miele appliances, Sub-Zero wine refrigerator, Nespresso Vertuo station, induction cooking, and artisan ceramic dinnerware from Sifnos potters.

• Master Bedrooms & En-Suites:
Four private bedroom sanctuaries outfitted with handcrafted Coco-Mat organic king mattresses, 1000-thread count Egyptian cotton linens, and spa-inspired en-suite bathrooms with rainfall showers and volcanic rock bathtubs.`,
    guestAccess: 'Guests have private and exclusive access to the entire 350 sq.m villa, private heated infinity pool, jacuzzi hot tub, sun terraces, wine cellar, and private laundry suite.',
    otherDetails: 'Daily gourmet Mediterranean breakfast prepared by our private chef is included with your reservation. Daily housekeeping and bespoke concierge service for catamaran cruises and winery reservations are complimentary.'
  },
  bedrooms: [
    {
      id: 'bed-1',
      title: 'Bedroom 1 (Master Suite)',
      bedType: '1 King Bed',
      features: 'Caldera view, En-suite rain shower, Private balcony, Walk-in closet',
      iconName: 'BedDouble'
    },
    {
      id: 'bed-2',
      title: 'Bedroom 2 (Caldera Suite)',
      bedType: '1 King Bed',
      features: 'Ocean view, En-suite volcanic stone bath, Terrace access',
      iconName: 'BedDouble'
    },
    {
      id: 'bed-3',
      title: 'Bedroom 3 (Sunset Suite)',
      bedType: '1 Queen Bed',
      features: 'Sunset panoramic views, En-suite shower, Smart HDTV',
      iconName: 'BedDouble'
    },
    {
      id: 'bed-4',
      title: 'Bedroom 4 (Garden Cave Suite)',
      bedType: '2 Single Beds (or 1 King)',
      features: 'Cycladic cave alcove, En-suite shower, Dedicated workspace',
      iconName: 'Bed'
    }
  ],
  photos: [
    {
      id: 'p-1',
      url: 'https://images.unsplash.com/photo-1570077188670-e3a8d69ac5ff?auto=format&fit=crop&w=1600&q=85',
      alt: 'Villa Asteria heated infinity pool overlooking Caldera and Aegean Sea',
      category: 'Infinity Pool & Caldera',
      caption: 'Private heated infinity pool suspended over the Oia cliffs'
    },
    {
      id: 'p-2',
      url: 'https://images.unsplash.com/photo-1512917774080-9991f1c4c750?auto=format&fit=crop&w=1200&q=80',
      alt: 'Luxury whitewashed living room with vaulted Cycladic ceilings',
      category: 'Living Room',
      caption: 'Vaulted open-concept living area with panoramic sea view sliders'
    },
    {
      id: 'p-3',
      url: 'https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1200&q=80',
      alt: 'Master bedroom with king bed and private ocean balcony',
      category: 'Bedrooms',
      caption: 'Master Suite featuring handcrafted Coco-Mat organic mattress and sea views'
    },
    {
      id: 'p-4',
      url: 'https://images.unsplash.com/photo-1600565193348-f74bd3c7ccdf?auto=format&fit=crop&w=1200&q=80',
      alt: 'Gourmet kitchen with marble island and Aegean vistas',
      category: 'Kitchen & Dining',
      caption: 'Chef kitchen with Miele appliances and Sifnos artisan ceramics'
    },
    {
      id: 'p-5',
      url: 'https://images.unsplash.com/photo-1533105079780-92b9be482077?auto=format&fit=crop&w=1200&q=80',
      alt: 'Terrace sunset lounge with fire table and evening ambient lighting',
      category: 'Terrace',
      caption: 'Sunset lounge terrace with gas fire table and panoramic golden hour views'
    },
    {
      id: 'p-6',
      url: 'https://images.unsplash.com/photo-1582719478250-c89cae4dc85b?auto=format&fit=crop&w=1200&q=80',
      alt: 'Minimalist spa bathroom with volcanic stone tub and rain shower',
      category: 'Bedrooms',
      caption: 'En-suite spa bath with custom sculpted stone bathtub'
    },
    {
      id: 'p-7',
      url: 'https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?auto=format&fit=crop&w=1200&q=80',
      alt: 'Second Caldera bedroom suite with whitewashed cave alcoves',
      category: 'Bedrooms',
      caption: 'Bedroom 2 with Cycladic arched niches and plush organic linens'
    },
    {
      id: 'p-8',
      url: 'https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=1200&q=80',
      alt: 'Al fresco dining table set for Mediterranean dinner under pergola',
      category: 'Terrace',
      caption: 'Shaded outdoor dining pergola for 10 guests with sunset panoramas'
    },
    {
      id: 'p-9',
      url: 'https://images.unsplash.com/photo-1540555700478-4be289fbecef?auto=format&fit=crop&w=1200&q=80',
      alt: 'Evening pool illumination with Caldera night lights',
      category: 'Infinity Pool & Caldera',
      caption: 'Underwater pool LED illumination against the twinkling lights of Oia'
    }
  ],
  amenities: [
    { name: 'Caldera & sea view', iconName: 'Eye', category: 'Scenic views', isFeatured: true, description: 'Direct, unobstructed panoramic views of the volcanic caldera' },
    { name: 'Private heated infinity pool', iconName: 'Waves', category: 'Outdoor', isFeatured: true, description: 'Heated to 28°C year-round with horizon edge' },
    { name: 'Dedicated workspace with 500 Mbps Wifi', iconName: 'Laptop', category: 'Internet and office', isFeatured: true, description: 'High-speed fiber connection suitable for 4K video calls' },
    { name: 'Free private on-site parking', iconName: 'Car', category: 'Parking & facilities', isFeatured: true, description: 'Dedicated reserved parking spot located 150m from villa' },
    { name: 'Chef-grade fully equipped kitchen', iconName: 'Utensils', category: 'Kitchen and dining', isFeatured: true, description: 'Miele appliances, Nespresso machine, wine cooler' },
    { name: 'Hot tub jacuzzi', iconName: 'Sparkles', category: 'Outdoor', isFeatured: true, description: 'Private heated hydrotherapy spa on the lower terrace' },
    { name: '65" 4K OLED Smart TV with Netflix', iconName: 'Tv', category: 'Entertainment', isFeatured: true, description: 'Apple TV 4K, HBO Max, Disney+, Sonos Arc soundbar' },
    { name: 'Free in-unit washer & dryer', iconName: 'Shirt', category: 'Bedroom & laundry', isFeatured: true, description: 'Complimentary organic detergent and steam iron' },
    { name: 'Central air conditioning & climate control', iconName: 'Wind', category: 'Heating and cooling', isFeatured: true, description: 'Individual smart thermostats in every room' },
    { name: 'EV level 2 car charger', iconName: 'Zap', category: 'Parking & facilities', isFeatured: true, description: 'Compatible with Tesla and standard Type 2 connectors' },

    // Additional categorized amenities for "Show all amenities modal"
    { name: 'Coco-Mat organic King mattresses', iconName: 'BedDouble', category: 'Bedroom & laundry', description: 'Hypoallergenic all-natural fiber beds' },
    { name: '1000-thread count Egyptian cotton sheets', iconName: 'Layers', category: 'Bedroom & laundry' },
    { name: 'Dyson Supersonic hair dryers in all baths', iconName: 'Wind', category: 'Bathroom' },
    { name: 'Luxury Korres organic toiletries', iconName: 'Sparkles', category: 'Bathroom' },
    { name: 'Volcanic stone soaking tub', iconName: 'Bath', category: 'Bathroom' },
    { name: 'Rainfall walk-in showers', iconName: 'ShowerHead', category: 'Bathroom' },
    { name: 'Sonos architectural multi-room sound', iconName: 'Volume2', category: 'Entertainment' },
    { name: 'Gas outdoor BBQ grill & fire table', iconName: 'Flame', category: 'Outdoor' },
    { name: 'Sun lounger daybeds & beach towels', iconName: 'Sun', category: 'Outdoor' },
    { name: 'Sub-Zero temperature-zoned wine cellar', iconName: 'Wine', category: 'Kitchen and dining' },
    { name: 'Nespresso Vertuo coffee machine & pods', iconName: 'Coffee', category: 'Kitchen and dining' },
    { name: 'Dishwasher & organic dish pods', iconName: 'CheckCircle2', category: 'Kitchen and dining' },
    { name: 'Daily complimentary housekeeping', iconName: 'Sparkles', category: 'Services' },
    { name: 'Private concierge service', iconName: 'UserCheck', category: 'Services' },
    { name: 'Luggage drop-off allowed', iconName: 'Luggage', category: 'Services' },
    { name: 'Smoke alarm & Carbon monoxide detector', iconName: 'ShieldAlert', category: 'Home safety' },
    { name: 'First aid emergency kit', iconName: 'HeartPulse', category: 'Home safety' },
    { name: 'Exterior perimeter security cameras', iconName: 'Camera', category: 'Home safety' }
  ],
  reviews: [
    {
      id: 'rev-1',
      author: {
        name: 'Sophia Montgomery',
        avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=200&q=80',
        location: 'London, United Kingdom',
        yearsOnAirbnb: '6 years on Airbnb'
      },
      rating: 5,
      date: 'August 2026',
      stayDetails: 'Stayed 5 nights · Group trip',
      comment: 'Villa Asteria exceeded every expectation. The caldera view from the infinity pool is genuinely unbelievable—better than the photos! Elena and Nikos were the most attentive hosts, organizing our private catamaran and catamaran sunset dinner seamlessly.',
      hostResponse: {
        date: 'August 2026',
        comment: 'Thank you so much Sophia! It was a delight hosting your wonderful family. You are always welcome back at Villa Asteria!'
      }
    },
    {
      id: 'rev-2',
      author: {
        name: 'Alexander & Claire Vance',
        avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=200&q=80',
        location: 'San Francisco, CA',
        yearsOnAirbnb: '8 years on Airbnb'
      },
      rating: 5,
      date: 'July 2026',
      stayDetails: 'Stayed 7 nights · Couples getaway',
      comment: 'The architectural design of this villa is pure genius. Having 500 Mbps wifi while overlooking the Aegean made working remotely unforgettable. Watching the Oia sunset from our private heated pool with zero crowds is the ultimate luxury.'
    },
    {
      id: 'rev-3',
      author: {
        name: 'Marcus Dubois',
        avatar: 'https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?auto=format&fit=crop&w=200&q=80',
        location: 'Paris, France',
        yearsOnAirbnb: '4 years on Airbnb'
      },
      rating: 5,
      date: 'June 2026',
      stayDetails: 'Stayed 4 nights · Family vacation',
      comment: 'Spotlessly clean, impeccably styled, and the gourmet breakfasts every morning were divine. Giannis the concierge went above and beyond. Truly a 10/10 experience.'
    },
    {
      id: 'rev-4',
      author: {
        name: 'Emily Zhang',
        avatar: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=200&q=80',
        location: 'Sydney, Australia',
        yearsOnAirbnb: '5 years on Airbnb'
      },
      rating: 5,
      date: 'May 2026',
      stayDetails: 'Stayed 6 nights · Friends retreat',
      comment: 'Hands down the best Airbnb we have ever stayed in anywhere in the world. The beds are super comfortable, the bathrooms feel like a 5-star Aman resort, and the location in Oia is unbeatable.'
    },
    {
      id: 'rev-5',
      author: {
        name: 'David & Hannah Becker',
        avatar: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&w=200&q=80',
        location: 'Munich, Germany',
        yearsOnAirbnb: '9 years on Airbnb'
      },
      rating: 5,
      date: 'April 2026',
      stayDetails: 'Stayed 4 nights · Honeymoon',
      comment: 'Our honeymoon here was like a fairytale. The heated pool temperature was perfect even during early spring evenings. Elena left us fresh local wine and delicacies upon check-in. Perfection!'
    },
    {
      id: 'rev-6',
      author: {
        name: 'Isabella Rossi',
        avatar: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=200&q=80',
        location: 'Milan, Italy',
        yearsOnAirbnb: '7 years on Airbnb'
      },
      rating: 5,
      date: 'March 2026',
      stayDetails: 'Stayed 5 nights · Group trip',
      comment: 'Everything from the keyless check-in to the sound system and kitchen amenities was flawless. We loved having private sunset cocktails on the terrace while avoiding all the crowded streets!'
    }
  ],
  houseRules: {
    checkIn: '3:00 PM – 8:00 PM',
    checkOut: '11:00 AM',
    selfCheckIn: 'Self check-in with smart keypad',
    rulesList: [
      '8 guests maximum',
      'No smoking inside the villa',
      'Commercial photography requires prior written host approval',
      'Quiet hours from 10:00 PM to 8:00 AM in compliance with local caldera community rules',
      'Pets allowed upon prior host confirmation'
    ]
  },
  safetyInfo: [
    'Carbon monoxide alarm installed & inspected',
    'Smoke alarms in all living areas and bedrooms',
    'Fire extinguisher and emergency first-aid kit in kitchen pantry',
    'Cliffside infinity pool has no safety gate (constant adult supervision required for minors)',
    'Exterior security cameras covering villa entrance gate only (no interior cameras)'
  ],
  cancellationPolicy: {
    summary: 'Free cancellation for 48 hours. Cancel at least 7 days before check-in for a 50% refund.',
    details: 'Review the Host’s full cancellation policy which applies even if you cancel for illness or disruptions caused by travel.'
  }
};
