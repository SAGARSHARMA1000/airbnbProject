'use client';

import React, { useState } from 'react';
import { Home, Compass, MapPin, Layers, Plus, Minus } from 'lucide-react';
import { ListingDetails } from '@/data/listingData';

interface LocationMapProps {
  listing: ListingDetails;
}

export const LocationMap: React.FC<LocationMapProps> = ({ listing }) => {
  const [mapType, setMapType] = useState<'standard' | 'satellite'>('standard');
  const [zoomLevel, setZoomLevel] = useState(15);

  return (
    <section id="location-section" className="py-12 border-b border-gray-200">
      <h3 className="text-2xl font-bold text-gray-900 mb-2">Where you&apos;ll be</h3>
      <p className="text-sm text-gray-700 font-normal mb-6 flex items-center gap-1.5">
        <MapPin className="w-4 h-4 text-gray-500" />
        <span>{listing.location.displayAddress}</span>
      </p>

      {/* Map Graphic Container with Interactive Controls */}
      <div className="relative w-full h-[400px] sm:h-[480px] rounded-3xl overflow-hidden border border-gray-200 shadow-inner bg-slate-100">
        {/* Background Map Visual: Stylized Vector or Satellite View */}
        <div
          className={`absolute inset-0 transition-all duration-500 ${
            mapType === 'satellite'
              ? 'bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-slate-900 via-sky-950 to-blue-900'
              : 'bg-[#e5e3df]'
          }`}
          style={{
            backgroundImage:
              mapType === 'standard'
                ? `radial-gradient(#d4d0c8 1px, transparent 1px), radial-gradient(#d4d0c8 1px, #e5e3df 1px)`
                : undefined,
            backgroundSize: `${20 * (zoomLevel / 15)}px ${20 * (zoomLevel / 15)}px`,
            backgroundPosition: '0 0, 10px 10px',
          }}
        >
          {/* Aegean Sea / Coastline Graphic Shapes */}
          <svg
            className="absolute inset-0 w-full h-full opacity-40 pointer-events-none"
            preserveAspectRatio="none"
            viewBox="0 0 800 500"
          >
            <path
              d="M0,0 C200,100 400,50 800,200 L800,500 L0,500 Z"
              fill={mapType === 'satellite' ? '#0f2942' : '#aadaff'}
            />
            <path
              d="M150,0 C300,180 500,120 750,350"
              fill="none"
              stroke={mapType === 'satellite' ? '#25517a' : '#ffffff'}
              strokeWidth="12"
            />
            {/* Oia Cliff Paths */}
            <path
              d="M100,150 Q300,220 550,180 T780,260"
              fill="none"
              stroke={mapType === 'satellite' ? '#5a6872' : '#f4f3f0'}
              strokeWidth="6"
              strokeDasharray="4 2"
            />
          </svg>

          {/* Central Property Marker Pin */}
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-20 flex flex-col items-center">
            {/* Exact Location Pulsing Bubble */}
            <div className="relative flex items-center justify-center">
              <span className="animate-ping absolute inline-flex h-20 w-20 rounded-full bg-[#FF385C] opacity-20" />
              <div className="relative bg-[#FF385C] text-white p-3 rounded-full shadow-2xl border-2 border-white flex items-center justify-center hover:scale-110 transition cursor-pointer">
                <Home className="w-5 h-5 fill-white text-white" />
              </div>
            </div>

            {/* Price Tag Bubble */}
            <div className="mt-2 bg-gray-900 text-white font-bold text-xs py-1.5 px-3 rounded-full shadow-lg border border-white/40 flex items-center gap-1">
              <span>${listing.pricing.basePricePerNight}</span>
              <span className="text-[10px] text-gray-300 font-normal">/ night</span>
            </div>
          </div>

          {/* Nearby Landmark Pins */}
          <div className="absolute top-1/4 left-1/3 z-10 hidden sm:flex items-center gap-1 bg-white/90 backdrop-blur-xs px-2.5 py-1 rounded-full text-[11px] font-semibold text-gray-800 shadow-md border border-gray-200">
            <Compass className="w-3.5 h-3.5 text-blue-600" />
            <span>Oia Castle Ruins (4 min walk)</span>
          </div>

          <div className="absolute bottom-1/4 right-1/4 z-10 hidden sm:flex items-center gap-1 bg-white/90 backdrop-blur-xs px-2.5 py-1 rounded-full text-[11px] font-semibold text-gray-800 shadow-md border border-gray-200">
            <Compass className="w-3.5 h-3.5 text-amber-600" />
            <span>Ammoudi Bay (7 min walk)</span>
          </div>
        </div>

        {/* Map View Toggle Controls (Top Right) */}
        <div className="absolute top-4 right-4 z-30 flex items-center bg-white rounded-xl shadow-md border border-gray-200 p-1 text-xs font-semibold">
          <button
            onClick={() => setMapType('standard')}
            className={`px-3 py-1.5 rounded-lg transition ${
              mapType === 'standard'
                ? 'bg-gray-900 text-white'
                : 'text-gray-700 hover:bg-gray-100'
            }`}
          >
            Map
          </button>
          <button
            onClick={() => setMapType('satellite')}
            className={`px-3 py-1.5 rounded-lg transition flex items-center gap-1 ${
              mapType === 'satellite'
                ? 'bg-gray-900 text-white'
                : 'text-gray-700 hover:bg-gray-100'
            }`}
          >
            <Layers className="w-3 h-3" />
            <span>Satellite</span>
          </button>
        </div>

        {/* Zoom Controls (Bottom Right) */}
        <div className="absolute bottom-4 right-4 z-30 flex flex-col bg-white rounded-xl shadow-md border border-gray-200 divide-y divide-gray-200 overflow-hidden">
          <button
            onClick={() => setZoomLevel((z) => Math.min(18, z + 1))}
            className="p-2 hover:bg-gray-100 text-gray-700 transition"
            aria-label="Zoom in"
          >
            <Plus className="w-4 h-4" />
          </button>
          <button
            onClick={() => setZoomLevel((z) => Math.max(12, z - 1))}
            className="p-2 hover:bg-gray-100 text-gray-700 transition"
            aria-label="Zoom out"
          >
            <Minus className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Location Guide Descriptions */}
      <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-8 text-sm text-gray-800 leading-relaxed">
        <div>
          <h4 className="font-semibold text-gray-900 mb-2">Oia, Santorini, Greece</h4>
          <p className="text-gray-600 font-normal">{listing.location.description}</p>
        </div>
        <div>
          <h4 className="font-semibold text-gray-900 mb-2">Getting around</h4>
          <p className="text-gray-600 font-normal">{listing.location.gettingAround}</p>
        </div>
      </div>
    </section>
  );
};
