'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { X, Star, Search } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { ReviewItem, ListingDetails } from '@/data/listingData';

interface ReviewsModalProps {
  isOpen: boolean;
  onClose: () => void;
  listing: ListingDetails;
}

export const ReviewsModal: React.FC<ReviewsModalProps> = ({
  isOpen,
  onClose,
  listing,
}) => {
  const [searchQuery, setSearchQuery] = useState('');

  if (!isOpen) return null;

  const filteredReviews = searchQuery.trim()
    ? listing.reviews.filter(
        (r) =>
          r.author.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
          r.comment.toLowerCase().includes(searchQuery.toLowerCase())
      )
    : listing.reviews;

  const categories = [
    { label: 'Cleanliness', score: listing.rating.categories.cleanliness },
    { label: 'Accuracy', score: listing.rating.categories.accuracy },
    { label: 'Communication', score: listing.rating.categories.communication },
    { label: 'Location', score: listing.rating.categories.location },
    { label: 'Check-in', score: listing.rating.categories.checkIn },
    { label: 'Value', score: listing.rating.categories.value },
  ];

  return (
    <AnimatePresence>
      <div
        role="dialog"
        aria-modal="true"
        aria-label="All Reviews Modal"
        className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4"
      >
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.95 }}
          className="bg-white rounded-3xl max-w-4xl w-full p-6 sm:p-8 shadow-2xl border border-gray-100 max-h-[90vh] flex flex-col"
        >
          {/* Header */}
          <div className="flex justify-between items-center pb-4 border-b border-gray-100">
            <button
              onClick={onClose}
              className="p-2 hover:bg-gray-100 rounded-full transition"
              aria-label="Close reviews modal"
            >
              <X className="w-5 h-5 text-gray-600" />
            </button>
            <div className="flex items-center gap-1.5 font-bold text-gray-900 text-lg">
              <Star className="w-5 h-5 fill-gray-900 text-gray-900" />
              <span>{listing.rating.overall.toFixed(2)}</span>
              <span>·</span>
              <span>{listing.rating.reviewCount} reviews</span>
            </div>
            <div className="w-9" />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-12 gap-8 flex-1 overflow-y-auto pt-6 pr-2">
            {/* Left Category Rating Summary Column (4 cols) */}
            <div className="md:col-span-4 space-y-4">
              <h4 className="font-bold text-gray-900 text-base">Overall ratings</h4>
              <div className="space-y-3">
                {categories.map((cat) => (
                  <div key={cat.label} className="text-xs">
                    <div className="flex justify-between font-medium text-gray-700 mb-1">
                      <span>{cat.label}</span>
                      <span className="font-bold text-gray-900">{cat.score.toFixed(1)}</span>
                    </div>
                    <div className="w-full bg-gray-200 h-1 rounded-full overflow-hidden">
                      <div
                        className="bg-gray-900 h-full rounded-full"
                        style={{ width: `${(cat.score / 5.0) * 100}%` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Right Reviews Feed (8 cols) */}
            <div className="md:col-span-8 flex flex-col space-y-6">
              {/* Search Bar */}
              <div className="relative">
                <Search className="w-4 h-4 text-gray-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search reviews..."
                  className="w-full pl-10 pr-4 py-2 rounded-full border border-gray-300 text-sm focus:outline-none focus:ring-2 focus:ring-black"
                />
              </div>

              {/* Reviews List */}
              <div className="space-y-6 divide-y divide-gray-100">
                {filteredReviews.length === 0 ? (
                  <p className="text-sm text-gray-500 py-6 text-center">
                    No reviews found matching &quot;{searchQuery}&quot;
                  </p>
                ) : (
                  filteredReviews.map((review: ReviewItem, idx: number) => (
                    <div key={review.id} className={idx === 0 ? '' : 'pt-6'}>
                      {/* Reviewer Header */}
                      <div className="flex items-center gap-3 mb-3">
                        <div className="relative w-10 h-10 rounded-full overflow-hidden bg-gray-100 shrink-0">
                          <Image
                            src={review.author.avatar}
                            alt={review.author.name}
                            fill
                            sizes="40px"
                            className="object-cover"
                          />
                        </div>
                        <div>
                          <h5 className="font-semibold text-gray-900 text-sm">
                            {review.author.name}
                          </h5>
                          <p className="text-[11px] text-gray-500">
                            {review.author.location} · {review.author.yearsOnAirbnb}
                          </p>
                        </div>
                      </div>

                      {/* Rating & Date */}
                      <div className="flex items-center gap-2 text-xs text-gray-700 mb-2">
                        <div className="flex text-gray-900">
                          {[...Array(review.rating)].map((_, i) => (
                            <Star key={i} className="w-3 h-3 fill-gray-900 text-gray-900" />
                          ))}
                        </div>
                        <span>·</span>
                        <span className="font-medium text-gray-900">{review.date}</span>
                        <span>·</span>
                        <span className="text-gray-500">{review.stayDetails}</span>
                      </div>

                      {/* Comment */}
                      <p className="text-sm text-gray-700 leading-relaxed font-normal">
                        {review.comment}
                      </p>

                      {/* Host Response */}
                      {review.hostResponse && (
                        <div className="mt-3 ml-4 pl-4 border-l-2 border-gray-200 bg-gray-50/70 p-3 rounded-r-xl text-xs text-gray-700 space-y-1">
                          <span className="font-semibold text-gray-900 block">
                            Response from {listing.host.name} · {review.hostResponse.date}
                          </span>
                          <p className="text-gray-600">{review.hostResponse.comment}</p>
                        </div>
                      )}
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
