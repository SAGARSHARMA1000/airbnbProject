'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { Award, Star, ShieldCheck, MessageSquare, Globe, Briefcase } from 'lucide-react';
import { ListingDetails } from '@/data/listingData';
import { ContactHostModal } from '@/components/ContactHostModal';

interface HostProfileSectionProps {
  listing: ListingDetails;
}

export const HostProfileSection: React.FC<HostProfileSectionProps> = ({ listing }) => {
  const [isContactModalOpen, setIsContactModalOpen] = useState(false);

  return (
    <>
      <section id="host-section" className="py-12 border-b border-gray-200">
        <h3 className="text-2xl font-bold text-gray-900 mb-8">Meet your Host</h3>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
          {/* Host Card Badge (Left 5 Cols) */}
          <div className="lg:col-span-5 bg-gradient-to-br from-gray-50 to-gray-100/60 border border-gray-200 rounded-3xl p-6 sm:p-8 shadow-sm flex flex-col items-center text-center">
            <div className="relative mb-4">
              <div className="w-24 h-24 rounded-full overflow-hidden border-2 border-white shadow-md relative">
                <Image
                  src={listing.host.avatar}
                  alt={listing.host.name}
                  fill
                  sizes="96px"
                  className="object-cover"
                />
              </div>
              {listing.host.isSuperhost && (
                <div className="absolute -bottom-2 -right-1 bg-[#FF385C] text-white p-1.5 rounded-full border-2 border-white shadow-sm">
                  <Award className="w-4 h-4 fill-white" />
                </div>
              )}
            </div>

            <h4 className="text-xl font-bold text-gray-900">{listing.host.name}</h4>
            <p className="text-xs text-gray-500 font-medium mt-0.5">
              Superhost · Hosting since {listing.host.hostingSince}
            </p>

            {/* Quick Stat Pill Grid */}
            <div className="grid grid-cols-3 gap-2 w-full mt-6 pt-6 border-t border-gray-200 text-center">
              <div>
                <span className="block text-base font-extrabold text-gray-900">
                  {listing.host.stats.reviews}
                </span>
                <span className="text-[10px] text-gray-500 uppercase font-semibold">
                  Reviews
                </span>
              </div>
              <div className="border-x border-gray-200 px-2">
                <div className="flex items-center justify-center gap-1 text-base font-extrabold text-gray-900">
                  <span>{listing.host.stats.rating.toFixed(2)}</span>
                  <Star className="w-3.5 h-3.5 fill-gray-900 text-gray-900" />
                </div>
                <span className="text-[10px] text-gray-500 uppercase font-semibold">
                  Rating
                </span>
              </div>
              <div>
                <span className="block text-base font-extrabold text-gray-900">
                  {listing.host.stats.yearsHosting}
                </span>
                <span className="text-[10px] text-gray-500 uppercase font-semibold">
                  Years
                </span>
              </div>
            </div>
          </div>

          {/* Host Details & Bio (Right 7 Cols) */}
          <div className="lg:col-span-7 flex flex-col justify-between space-y-6">
            <div className="space-y-4">
              <div className="space-y-2 text-sm text-gray-800">
                <div className="flex items-center gap-2 text-gray-700">
                  <Briefcase className="w-4 h-4 text-gray-500" />
                  <span>Host details: Architect & Hospitality Curator</span>
                </div>
                <div className="flex items-center gap-2 text-gray-700">
                  <Globe className="w-4 h-4 text-gray-500" />
                  <span>Speaks {listing.host.languages.join(', ')}</span>
                </div>
              </div>

              <p className="text-sm text-gray-700 leading-relaxed font-normal">
                {listing.host.bio}
              </p>

              {/* Co-host list */}
              {listing.host.coHosts.length > 0 && (
                <div className="pt-2">
                  <span className="text-xs font-bold uppercase tracking-wider text-gray-500 block mb-2">
                    Co-hosts
                  </span>
                  <div className="flex items-center gap-3">
                    {listing.host.coHosts.map((cohost, idx) => (
                      <div key={idx} className="flex items-center gap-2 bg-gray-50 border border-gray-200 px-3 py-1.5 rounded-full text-xs">
                        <div className="relative w-6 h-6 rounded-full overflow-hidden">
                          <Image
                            src={cohost.avatar}
                            alt={cohost.name}
                            fill
                            sizes="24px"
                            className="object-cover"
                          />
                        </div>
                        <span className="font-medium text-gray-800">
                          {cohost.name} ({cohost.role})
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Message Host & Safety Notice */}
            <div className="pt-4 border-t border-gray-100 space-y-4">
              <div className="text-xs text-gray-600">
                <p>Response rate: <span className="font-semibold text-gray-900">{listing.host.responseRate}</span></p>
                <p>Responds {listing.host.responseTime}</p>
              </div>

              <button
                onClick={() => setIsContactModalOpen(true)}
                className="inline-flex items-center gap-2 bg-gray-900 hover:bg-black text-white px-6 py-3 rounded-xl font-semibold text-sm transition cursor-pointer shadow-xs"
              >
                <MessageSquare className="w-4 h-4" />
                <span>Message Host</span>
              </button>

              <div className="flex items-start gap-2.5 text-[11px] text-gray-500 leading-normal pt-2">
                <ShieldCheck className="w-4 h-4 text-[#FF385C] shrink-0 mt-0.5" />
                <span>
                  To protect your payment, never transfer money or communicate outside of the Airbnb website or app.
                </span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Host Modal */}
      <ContactHostModal
        isOpen={isContactModalOpen}
        onClose={() => setIsContactModalOpen(false)}
        listing={listing}
      />
    </>
  );
};
