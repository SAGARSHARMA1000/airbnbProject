'use client';

import React from 'react';
import Image from 'next/image';
import { Award } from 'lucide-react';
import { ListingDetails } from '@/data/listingData';

interface HostQuickInfoProps {
  listing: ListingDetails;
  onHostClick?: () => void;
}

export const HostQuickInfo: React.FC<HostQuickInfoProps> = ({
  listing,
  onHostClick,
}) => {
  return (
    <div className="py-6 border-b border-gray-200 flex items-center justify-between">
      <div>
        <h2 className="text-xl sm:text-[22px] font-semibold text-gray-900 leading-snug">
          {listing.stats.propertyType} hosted by {listing.host.name}
        </h2>
        <p className="text-sm text-gray-600 mt-1 font-normal">
          {listing.stats.guests} guests · {listing.stats.bedrooms} bedrooms ·{' '}
          {listing.stats.beds} beds · {listing.stats.baths} baths
        </p>
      </div>

      <button
        onClick={onHostClick}
        className="relative group cursor-pointer shrink-0 ml-4"
        aria-label={`View ${listing.host.name}'s profile`}
      >
        <div className="relative w-14 h-14 rounded-full overflow-hidden border border-gray-200 shadow-xs">
          <Image
            src={listing.host.avatar}
            alt={listing.host.name}
            fill
            sizes="56px"
            className="object-cover group-hover:scale-105 transition duration-200"
          />
        </div>
        {listing.host.isSuperhost && (
          <div className="absolute -bottom-1 -right-1 bg-[#FF385C] text-white p-1 rounded-full border-2 border-white shadow-xs">
            <Award className="w-3.5 h-3.5 fill-white" />
          </div>
        )}
      </button>
    </div>
  );
};
