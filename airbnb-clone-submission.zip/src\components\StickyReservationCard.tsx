'use client';

import React, { useState, useRef, useEffect } from 'react';
import { Star, ChevronDown, ChevronUp, Plus, Minus, Flag, Sparkles } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { ListingDetails } from '@/data/listingData';
import { format, differenceInCalendarDays } from 'date-fns';
import confetti from 'canvas-confetti';
import { ReservationSuccessModal } from './ReservationSuccessModal';

interface StickyReservationCardProps {
  listing: ListingDetails;
  checkIn: Date | null;
  checkOut: Date | null;
  onOpenCalendar: () => void;
  onScrollToReviews: () => void;
}

export const StickyReservationCard: React.FC<StickyReservationCardProps> = ({
  listing,
  checkIn,
  checkOut,
  onOpenCalendar,
  onScrollToReviews,
}) => {
  const [isGuestDropdownOpen, setIsGuestDropdownOpen] = useState(false);
  const [adults, setAdults] = useState(2);
  const [childrenCount, setChildrenCount] = useState(0);
  const [infants, setInfants] = useState(0);
  const [pets, setPets] = useState(0);
  const [isSuccessModalOpen, setIsSuccessModalOpen] = useState(false);
  const [isReportModalOpen, setIsReportModalOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Close dropdown on click outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsGuestDropdownOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const totalGuests = adults + childrenCount;
  const maxGuests = listing.stats.guests;

  // Nights calculation: default to 5 nights if not selected
  const nights = checkIn && checkOut ? Math.max(1, differenceInCalendarDays(checkOut, checkIn)) : 5;

  // Pricing math
  const baseSubtotal = nights * listing.pricing.basePricePerNight;
  const hasWeeklyDiscount = nights >= 7;
  const discount = hasWeeklyDiscount
    ? Math.round(baseSubtotal * (listing.pricing.weeklyDiscountPercentage / 100))
    : 0;
  const discountedSubtotal = baseSubtotal - discount;
  const cleaningFee = listing.pricing.cleaningFee;
  const serviceFee = Math.round(discountedSubtotal * listing.pricing.serviceFeeRate);
  const taxes = Math.round((discountedSubtotal + cleaningFee + serviceFee) * listing.pricing.taxRate);
  const total = discountedSubtotal + cleaningFee + serviceFee + taxes;

  const handleReserve = () => {
    // Fire confetti celebration
    try {
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#FF385C', '#00A699', '#FC642D', '#484848', '#FFB400'],
      });
    } catch {
      // ignore
    }
    setIsSuccessModalOpen(true);
  };

  return (
    <>
      <div className="sticky top-28 bg-white border border-gray-200 rounded-3xl p-6 shadow-xl transition-shadow hover:shadow-2xl">
        {/* Header: Price & Rating */}
        <div className="flex items-baseline justify-between mb-6">
          <div className="flex items-baseline gap-1">
            <span className="text-2xl font-bold text-gray-900">
              ${listing.pricing.basePricePerNight}
            </span>
            <span className="text-gray-500 text-sm font-normal">night</span>
          </div>

          <button
            onClick={onScrollToReviews}
            className="flex items-center gap-1 text-xs font-semibold text-gray-900 hover:underline cursor-pointer"
          >
            <Star className="w-3.5 h-3.5 fill-gray-900 text-gray-900" />
            <span>{listing.rating.overall.toFixed(2)}</span>
            <span className="text-gray-400 font-normal">·</span>
            <span className="text-gray-500 underline font-normal">
              {listing.rating.reviewCount} reviews
            </span>
          </button>
        </div>

        {/* Date & Guest Input Box */}
        <div className="border border-gray-300 rounded-2xl overflow-hidden mb-4 shadow-2xs">
          {/* Check-in / Checkout Split */}
          <div
            onClick={onOpenCalendar}
            className="grid grid-cols-2 divide-x divide-gray-300 border-b border-gray-300 cursor-pointer bg-white hover:bg-gray-50/60 transition"
          >
            <div className="p-3">
              <span className="block text-[10px] font-extrabold uppercase tracking-wider text-gray-800">
                Check-in
              </span>
              <span className="block text-xs font-medium text-gray-900 truncate mt-0.5">
                {checkIn ? format(checkIn, 'M/d/yyyy') : '10/12/2026'}
              </span>
            </div>
            <div className="p-3">
              <span className="block text-[10px] font-extrabold uppercase tracking-wider text-gray-800">
                Checkout
              </span>
              <span className="block text-xs font-medium text-gray-900 truncate mt-0.5">
                {checkOut ? format(checkOut, 'M/d/yyyy') : '10/17/2026'}
              </span>
            </div>
          </div>

          {/* Guest Selector Trigger */}
          <div className="relative" ref={dropdownRef}>
            <div
              onClick={() => setIsGuestDropdownOpen(!isGuestDropdownOpen)}
              className="p-3 flex items-center justify-between cursor-pointer bg-white hover:bg-gray-50/60 transition"
            >
              <div>
                <span className="block text-[10px] font-extrabold uppercase tracking-wider text-gray-800">
                  Guests
                </span>
                <span className="block text-xs font-medium text-gray-900 truncate mt-0.5">
                  {totalGuests} {totalGuests === 1 ? 'guest' : 'guests'}
                  {infants > 0 && `, ${infants} infant`}
                  {pets > 0 && `, ${pets} pet`}
                </span>
              </div>
              {isGuestDropdownOpen ? (
                <ChevronUp className="w-4 h-4 text-gray-600" />
              ) : (
                <ChevronDown className="w-4 h-4 text-gray-600" />
              )}
            </div>

            {/* Guest Dropdown Stepper Popover */}
            <AnimatePresence>
              {isGuestDropdownOpen && (
                <motion.div
                  initial={{ opacity: 0, y: -5 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -5 }}
                  className="absolute left-0 right-0 top-full mt-1 bg-white border border-gray-200 rounded-2xl shadow-xl p-4 z-40 space-y-4"
                >
                  {/* Adults */}
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="block text-sm font-semibold text-gray-900">Adults</span>
                      <span className="text-xs text-gray-500">Age 13+</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <button
                        disabled={adults <= 1}
                        onClick={() => setAdults((prev) => Math.max(1, prev - 1))}
                        className="w-8 h-8 rounded-full border border-gray-300 flex items-center justify-center disabled:opacity-30 hover:border-gray-900 transition"
                      >
                        <Minus className="w-3.5 h-3.5 text-gray-600" />
                      </button>
                      <span className="w-5 text-center text-sm font-semibold text-gray-900">
                        {adults}
                      </span>
                      <button
                        disabled={totalGuests >= maxGuests}
                        onClick={() => setAdults((prev) => prev + 1)}
                        className="w-8 h-8 rounded-full border border-gray-300 flex items-center justify-center disabled:opacity-30 hover:border-gray-900 transition"
                      >
                        <Plus className="w-3.5 h-3.5 text-gray-600" />
                      </button>
                    </div>
                  </div>

                  {/* Children */}
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="block text-sm font-semibold text-gray-900">Children</span>
                      <span className="text-xs text-gray-500">Ages 2–12</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <button
                        disabled={childrenCount <= 0}
                        onClick={() => setChildrenCount((prev) => Math.max(0, prev - 1))}
                        className="w-8 h-8 rounded-full border border-gray-300 flex items-center justify-center disabled:opacity-30 hover:border-gray-900 transition"
                      >
                        <Minus className="w-3.5 h-3.5 text-gray-600" />
                      </button>
                      <span className="w-5 text-center text-sm font-semibold text-gray-900">
                        {childrenCount}
                      </span>
                      <button
                        disabled={totalGuests >= maxGuests}
                        onClick={() => setChildrenCount((prev) => prev + 1)}
                        className="w-8 h-8 rounded-full border border-gray-300 flex items-center justify-center disabled:opacity-30 hover:border-gray-900 transition"
                      >
                        <Plus className="w-3.5 h-3.5 text-gray-600" />
                      </button>
                    </div>
                  </div>

                  {/* Infants */}
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="block text-sm font-semibold text-gray-900">Infants</span>
                      <span className="text-xs text-gray-500">Under 2</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <button
                        disabled={infants <= 0}
                        onClick={() => setInfants((prev) => Math.max(0, prev - 1))}
                        className="w-8 h-8 rounded-full border border-gray-300 flex items-center justify-center disabled:opacity-30 hover:border-gray-900 transition"
                      >
                        <Minus className="w-3.5 h-3.5 text-gray-600" />
                      </button>
                      <span className="w-5 text-center text-sm font-semibold text-gray-900">
                        {infants}
                      </span>
                      <button
                        disabled={infants >= 5}
                        onClick={() => setInfants((prev) => prev + 1)}
                        className="w-8 h-8 rounded-full border border-gray-300 flex items-center justify-center disabled:opacity-30 hover:border-gray-900 transition"
                      >
                        <Plus className="w-3.5 h-3.5 text-gray-600" />
                      </button>
                    </div>
                  </div>

                  {/* Pets */}
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="block text-sm font-semibold text-gray-900">Pets</span>
                      <span className="text-xs text-gray-500">Service animals welcome</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <button
                        disabled={pets <= 0}
                        onClick={() => setPets((prev) => Math.max(0, prev - 1))}
                        className="w-8 h-8 rounded-full border border-gray-300 flex items-center justify-center disabled:opacity-30 hover:border-gray-900 transition"
                      >
                        <Minus className="w-3.5 h-3.5 text-gray-600" />
                      </button>
                      <span className="w-5 text-center text-sm font-semibold text-gray-900">
                        {pets}
                      </span>
                      <button
                        disabled={pets >= 2}
                        onClick={() => setPets((prev) => prev + 1)}
                        className="w-8 h-8 rounded-full border border-gray-300 flex items-center justify-center disabled:opacity-30 hover:border-gray-900 transition"
                      >
                        <Plus className="w-3.5 h-3.5 text-gray-600" />
                      </button>
                    </div>
                  </div>

                  <p className="text-[11px] text-gray-500 leading-tight">
                    This place has a maximum of {maxGuests} guests, not including infants.
                  </p>

                  <div className="flex justify-end pt-2 border-t border-gray-100">
                    <button
                      onClick={() => setIsGuestDropdownOpen(false)}
                      className="text-xs font-bold underline text-gray-900 hover:text-black py-1 px-3"
                    >
                      Close
                    </button>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>

        {/* Reserve Action Button */}
        <motion.button
          whileHover={{ scale: 1.01 }}
          whileTap={{ scale: 0.98 }}
          onClick={handleReserve}
          className="w-full bg-gradient-to-r from-[#FF385C] via-[#E00B41] to-[#D70466] text-white font-semibold py-3.5 px-6 rounded-xl hover:opacity-95 transition shadow-md flex items-center justify-center gap-2 cursor-pointer text-base"
        >
          <Sparkles className="w-4 h-4" />
          <span>Reserve</span>
        </motion.button>

        <p className="text-center text-xs text-gray-500 mt-3 font-normal">
          You won&apos;t be charged yet
        </p>

        {/* Real-time Dynamic Pricing Breakdown */}
        <div className="mt-6 space-y-3 text-sm text-gray-700 font-normal">
          <div className="flex justify-between">
            <span className="underline">
              ${listing.pricing.basePricePerNight} x {nights} nights
            </span>
            <span>${baseSubtotal.toLocaleString()}</span>
          </div>

          {discount > 0 && (
            <div className="flex justify-between text-emerald-600 font-medium">
              <span>Weekly stay discount ({listing.pricing.weeklyDiscountPercentage}%)</span>
              <span>-${discount.toLocaleString()}</span>
            </div>
          )}

          <div className="flex justify-between">
            <span className="underline">Cleaning fee</span>
            <span>${cleaningFee.toLocaleString()}</span>
          </div>

          <div className="flex justify-between">
            <span className="underline">Airbnb service fee</span>
            <span>${serviceFee.toLocaleString()}</span>
          </div>

          <div className="flex justify-between">
            <span className="underline">Estimated taxes & fees</span>
            <span>${taxes.toLocaleString()}</span>
          </div>

          <div className="pt-4 border-t border-gray-200 flex justify-between font-bold text-gray-900 text-base">
            <span>Total before taxes</span>
            <span>${(discountedSubtotal + cleaningFee + serviceFee).toLocaleString()}</span>
          </div>

          <div className="flex justify-between font-bold text-gray-900 text-sm text-gray-500">
            <span>Total with taxes</span>
            <span className="text-gray-900 font-bold text-base">
              ${total.toLocaleString()}
            </span>
          </div>
        </div>
      </div>

      {/* Report this listing */}
      <div className="mt-6 text-center">
        <button
          onClick={() => setIsReportModalOpen(true)}
          className="inline-flex items-center gap-2 text-xs font-semibold text-gray-500 hover:text-gray-900 underline cursor-pointer"
        >
          <Flag className="w-3.5 h-3.5" />
          <span>Report this listing</span>
        </button>
      </div>

      {/* Confirmation Modal */}
      <ReservationSuccessModal
        isOpen={isSuccessModalOpen}
        onClose={() => setIsSuccessModalOpen(false)}
        listing={listing}
        checkIn={checkIn}
        checkOut={checkOut}
        guestsCount={{ adults, children: childrenCount, infants, pets }}
        pricingBreakdown={{
          nights,
          baseSubtotal,
          cleaningFee,
          serviceFee,
          taxes,
          discount,
          total,
        }}
      />

      {/* Report Listing Modal */}
      <AnimatePresence>
        {isReportModalOpen && (
          <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-gray-100"
            >
              <h3 className="text-lg font-bold text-gray-900 mb-2">Why are you reporting this listing?</h3>
              <p className="text-xs text-gray-500 mb-4">
                This won&apos;t be shared with the Host.
              </p>
              <div className="space-y-2 text-sm">
                {[
                  "It's inaccurate or incorrect",
                  "It's not a real place to stay",
                  "It's a scam or fraudulent",
                  "It's offensive or discriminatory",
                  'Something else',
                ].map((reason, idx) => (
                  <label
                    key={idx}
                    className="flex items-center gap-3 p-3 rounded-xl border border-gray-200 hover:bg-gray-50 cursor-pointer"
                  >
                    <input type="radio" name="report_reason" className="text-black focus:ring-black" />
                    <span className="text-gray-800 text-xs font-medium">{reason}</span>
                  </label>
                ))}
              </div>
              <div className="flex justify-end gap-3 mt-6 pt-4 border-t border-gray-100">
                <button
                  onClick={() => setIsReportModalOpen(false)}
                  className="px-4 py-2 text-xs font-semibold text-gray-700 hover:bg-gray-100 rounded-xl transition"
                >
                  Cancel
                </button>
                <button
                  onClick={() => {
                    alert('Thank you. Our Trust & Safety team has received your report.');
                    setIsReportModalOpen(false);
                  }}
                  className="px-4 py-2 text-xs font-semibold bg-gray-900 text-white rounded-xl hover:bg-black transition"
                >
                  Submit Report
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </>
  );
};
