'use client';

import React from 'react';
import { DynamicIcon } from '@/components/DynamicIcon';

interface HighlightItem {
  title: string;
  description: string;
  iconName: string;
}

interface HighlightsSectionProps {
  highlights: HighlightItem[];
}

export const HighlightsSection: React.FC<HighlightsSectionProps> = ({ highlights }) => {
  return (
    <div className="py-6 border-b border-gray-200 space-y-6">
      {highlights.map((item, idx) => (
        <div key={idx} className="flex items-start gap-4">
          <div className="text-gray-800 pt-0.5 shrink-0">
            <DynamicIcon name={item.iconName} className="w-6 h-6 stroke-[1.75]" />
          </div>
          <div>
            <h3 className="text-base font-semibold text-gray-900 leading-snug">
              {item.title}
            </h3>
            <p className="text-sm text-gray-500 mt-0.5 leading-relaxed font-normal">
              {item.description}
            </p>
          </div>
        </div>
      ))}
    </div>
  );
};
