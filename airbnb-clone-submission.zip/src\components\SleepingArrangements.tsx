'use client';

import React from 'react';
import { BedDouble, Bed } from 'lucide-react';
import { BedroomItem } from '@/data/listingData';

interface SleepingArrangementsProps {
  bedrooms: BedroomItem[];
}

export const SleepingArrangements: React.FC<SleepingArrangementsProps> = ({
  bedrooms,
}) => {
  return (
    <div className="py-8 border-b border-gray-200">
      <h3 className="text-xl sm:text-[22px] font-semibold text-gray-900 mb-6">
        Where you&apos;ll sleep
      </h3>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {bedrooms.map((bed) => (
          <div
            key={bed.id}
            className="border border-gray-200 rounded-2xl p-5 hover:border-gray-300 hover:shadow-xs transition bg-white flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center gap-2 text-gray-800 mb-4">
                {bed.iconName === 'Bed' ? (
                  <Bed className="w-6 h-6 stroke-[1.5]" />
                ) : (
                  <BedDouble className="w-6 h-6 stroke-[1.5]" />
                )}
              </div>
              <h4 className="font-semibold text-gray-900 text-sm mb-1">
                {bed.title}
              </h4>
              <p className="text-xs text-gray-500 font-normal">{bed.bedType}</p>
            </div>
            <p className="text-[11px] text-gray-400 mt-3 pt-3 border-t border-gray-100 font-light">
              {bed.features}
            </p>
          </div>
        ))}
      </div>
    </div>
  );
};
