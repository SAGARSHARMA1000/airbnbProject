'use client';

import React, { useState } from 'react';
import Image from 'next/image';
import { X, Copy, Check, MessageCircle, Mail, Share2 } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { ListingDetails } from '@/data/listingData';

interface ShareModalProps {
  isOpen: boolean;
  onClose: () => void;
  listing: ListingDetails;
}

export const ShareModal: React.FC<ShareModalProps> = ({
  isOpen,
  onClose,
  listing,
}) => {
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const handleCopyLink = () => {
    if (typeof window !== 'undefined') {
      navigator.clipboard.writeText(window.location.href);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const shareOptions = [
    { label: 'Copy Link', icon: copied ? Check : Copy, action: handleCopyLink, highlight: copied },
    { label: 'WhatsApp', icon: MessageCircle, action: () => window.open(`https://wa.me/?text=${encodeURIComponent(listing.title + ' ' + (typeof window !== 'undefined' ? window.location.href : ''))}`, '_blank') },
    { label: 'Email', icon: Mail, action: () => window.open(`mailto:?subject=${encodeURIComponent(listing.title)}&body=${encodeURIComponent(typeof window !== 'undefined' ? window.location.href : '')}`) },
    { label: 'Messenger', icon: Share2, action: () => alert('Opening Messenger...') },
  ];

  return (
    <AnimatePresence>
      <div
        role="dialog"
        aria-modal="true"
        aria-label="Share listing"
        className="fixed inset-0 z-50 bg-black/50 backdrop-blur-xs flex items-center justify-center p-4"
      >
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.95 }}
          className="bg-white rounded-3xl max-w-md w-full p-6 sm:p-8 shadow-2xl border border-gray-100"
        >
          {/* Header */}
          <div className="flex justify-between items-center pb-4 border-b border-gray-100 mb-6">
            <h3 className="text-xl font-bold text-gray-900">Share this place</h3>
            <button
              onClick={onClose}
              className="p-2 hover:bg-gray-100 rounded-full transition"
              aria-label="Close share modal"
            >
              <X className="w-5 h-5 text-gray-600" />
            </button>
          </div>

          {/* Listing Preview Card */}
          <div className="flex items-center gap-3 p-3 rounded-2xl border border-gray-200 bg-gray-50/60 mb-6">
            <div className="relative w-16 h-16 rounded-xl overflow-hidden shrink-0">
              <Image
                src={listing.photos[0].url}
                alt={listing.title}
                fill
                sizes="64px"
                className="object-cover"
              />
            </div>
            <div className="min-w-0">
              <h4 className="font-semibold text-xs text-gray-900 truncate">
                {listing.title}
              </h4>
              <p className="text-[11px] text-gray-500 truncate mt-0.5">
                ★ {listing.rating.overall.toFixed(2)} · {listing.location.displayAddress}
              </p>
              <p className="text-xs font-bold text-gray-900 mt-1">
                ${listing.pricing.basePricePerNight} / night
              </p>
            </div>
          </div>

          {/* Share Grid */}
          <div className="grid grid-cols-2 gap-3">
            {shareOptions.map((opt, idx) => {
              const Icon = opt.icon;
              return (
                <button
                  key={idx}
                  onClick={opt.action}
                  className={`flex items-center gap-3 p-3 rounded-2xl border transition text-left text-xs font-semibold cursor-pointer ${
                    opt.highlight
                      ? 'border-emerald-500 bg-emerald-50 text-emerald-900'
                      : 'border-gray-200 hover:bg-gray-50 text-gray-800'
                  }`}
                >
                  <Icon className={`w-4 h-4 ${opt.highlight ? 'text-emerald-600' : 'text-gray-700'}`} />
                  <span>{opt.highlight ? 'Copied Link!' : opt.label}</span>
                </button>
              );
            })}
          </div>
        </motion.div>
      </div>
    </AnimatePresence>
  );
};
